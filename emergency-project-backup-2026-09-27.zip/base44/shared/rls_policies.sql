-- ============================================================
-- حساب صراف — P0-1: RLS Policies (Defense in Depth)
-- ============================================================
-- این اسکریپت Policyهای صریح Supabase RLS را ایجاد می‌کند.
--
-- اصول طراحی:
-- 1. Service Role (بک‌اند) همیشه RLS را دور می‌زند → بدون Regression
-- 2. anon key (VITE_SUPABASE_KEY) در فرانت‌اند expose است → باید محدود شود
-- 3. جداول عمومی (قوانین، قیمت‌گذاری، محصولات) → فقط خواندن برای anon
-- 4. جداول tenant-scoped → DENY ALL برای anon/authenticated (بدون Policy = deny)
-- 5. هیچ عملیات نوشتن برای anon/authenticated مجاز نیست
--
-- Idempotent: безопасно برای اجرای چندباره (DROP + CREATE)
-- ============================================================

-- ============================================================
-- ۱. جداول عمومی — خواندن فقط برای anon و authenticated
-- ============================================================

-- rules: قوانین و مقررات (نمایش عمومی)
DROP POLICY IF EXISTS "public_read_rules" ON rules;
CREATE POLICY "public_read_rules" ON rules
  FOR SELECT TO anon, authenticated
  USING (is_active = true);

-- feature_settings: وضعیت قابلیت‌ها (نمایش عمومی)
DROP POLICY IF EXISTS "public_read_feature_settings" ON feature_settings;
CREATE POLICY "public_read_feature_settings" ON feature_settings
  FOR SELECT TO anon, authenticated
  USING (true);

-- pricing_plans: پلن‌های قیمت‌گذاری (نمایش عمومی)
DROP POLICY IF EXISTS "public_read_pricing_plans" ON pricing_plans;
CREATE POLICY "public_read_pricing_plans" ON pricing_plans
  FOR SELECT TO anon, authenticated
  USING (active = true);

-- online_products: کاتالوگ محصولات (فقط فعال‌ها)
DROP POLICY IF EXISTS "public_read_online_products" ON online_products;
CREATE POLICY "public_read_online_products" ON online_products
  FOR SELECT TO anon, authenticated
  USING (enabled = true);

-- rates: TENANT-SCOPED (دارای exchange_code) — بدون Policy = DENY ALL
-- نرخ‌ها از طریق بک‌اند (service_role) با فیلتر show_to_anonymous بازگردانده می‌شوند.

-- ============================================================
-- ۲. جداول tenant-scoped — بدون Policy = DENY ALL
-- ============================================================
-- این جداول Policy ندارند → PostgreSQL به‌صورت پیش‌فرض همه دسترسی‌ها
-- را برای anon و authenticated رد می‌کند. فقط service_role (بک‌اند)
-- می‌تواند داده‌ها را بخواند/بنویسد چون RLS را دور می‌زند.
-- ============================================================

-- ============================================================
-- ۳. عملیات نوشتن — بدون Policy = DENY ALL
-- ============================================================
-- همه نوشتن‌ها از طریق بک‌اند (service_role) انجام می‌شوند که
-- RLS را دور می‌زند و tenant isolation را در سطح application اعمال می‌کند.
-- ============================================================

-- ============================================================
-- ۴. اطمینان از فعال بودن RLS روی همه جداول موجود
-- (به‌صورت خودکار جداول ناموجود را نادیده می‌گیرد)
-- ============================================================
DO $$
DECLARE
    t TEXT;
    tbls TEXT[] := ARRAY[
        'users', 'exchanges', 'customers', 'documents', 'transfers',
        'conversions', 'treasury_transactions', 'bank_accounts',
        'bank_transactions', 'journal_entries', 'ledger_entries',
        'rates', 'idempotency_keys', 'employees', 'origins', 'safes',
        'rules', 'feature_settings', 'app_settings', 'audit_logs',
        'wallet_transactions', 'charge_orders', 'online_requests',
        'online_products', 'wallets', 'wallet_withdrawal_requests',
        'wallet_topup_requests', 'wallet_bans', 'customer_notifications',
        'customer_transfer_requests', 'customer_links', 'email_otps',
        'user_notifications', 'user_permissions', 'user_feedback',
        'support_tickets', 'support_messages', 'error_reports',
        'bank_gateways', 'payment_transactions', 'chat_groups',
        'chat_group_members', 'chat_messages', 'message_reports',
        'sellers', 'packages', 'pricing_plans', 'plan_quotas',
        'quota_change_logs', 'referrals', 'agency_links',
        'backup_records', 'rate_settings', 'text_labels'
    ];
BEGIN
    FOREACH t IN ARRAY tbls LOOP
        IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = t) THEN
            EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
            RAISE NOTICE 'RLS enabled on: %', t;
        ELSE
            RAISE NOTICE 'Skipped (not found): %', t;
        END IF;
    END LOOP;
END $$;

-- ============================================================
-- پایان P0-1
-- ============================================================