/**
 * حساب صراف — Backend function (secured)
 *
 * Security model:
 *  - Stateless signed session tokens (HMAC-SHA256 over {uid, role, exp}).
 *    Signed with SUPABASE_SERVICE_KEY (server-only). No sessions table needed.
 *  - Passwords: PBKDF2 (100k iterations, SHA-256) stored in the existing
 *    `password` column with a `pbkdf2$salt$hash` prefix. Legacy plaintext
 *    passwords are upgraded to a hash on next successful login.
 *  - Rate limiting: failed login attempts recorded in `audit_logs`; 5 failures
 *    in 15 minutes locks the identifier out.
 *  - Tenant isolation: every CRUD call is scoped to the caller's exchange_code
 *    (exchange role), read-only & self-scoped (customer role), or full (creator).
 *  - Audit logging: login, logout, create/update/delete, password change, etc.
 */

import { createClient } from 'npm:@supabase/supabase-js@2';

// ============================================================
// HELPERS
// ============================================================
// Extract the redirect origin from the request, falling back to the
// hardcoded Base44 URL only when the origin cannot be determined.
// This keeps the app working inside Base44 today and on a custom
// domain after migration.
function getEmailRedirectUrl(req: any): string {
  try {
    const origin = req?.headers?.get?.('origin');
    if (origin) return `${origin}/login`;
    const urlStr = req?.url;
    if (urlStr) {
      const u = new URL(urlStr);
      return `${u.origin}/login`;
    }
  } catch { /* fall through to default */ }
  return 'https://motherapp.base44.app/login';
}

// ============================================================
// CONSTANTS
// ============================================================
const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours
const LOCK_WINDOW_MS = 15 * 60 * 1000;      // 15 minutes
const LOCK_MAX_FAILS = 5;

const EXCHANGE_SCOPED = new Set([
  'customers', 'documents', 'transfers', 'conversions',
  'treasury_transactions', 'bank_accounts', 'bank_transactions',
  'journal_entries', 'ledger_entries', 'rates', 'employees',
  'origins', 'wallet_transactions', 'charge_orders', 'online_requests',
  'safes',
]);

// Tables that have registered_by / registered_by_user_id columns
const HAS_REGISTERED_BY = new Set([
  'documents', 'transfers', 'conversions', 'treasury_transactions',
  'bank_transactions', 'journal_entries', 'ledger_entries', 'rates',
  'wallet_transactions', 'charge_orders', 'online_requests', 'safes',
]);

const CUSTOMER_READ_TABLES = new Set([
  'rates', 'conversions', 'transfers',
  'wallets', 'wallet_transactions', 'charge_orders', 'customer_notifications',
  'customer_transfer_requests', 'customer_links',
]);

// Support system tables (tenant-scoped via user_id + exchange_code)
const SUPPORT_TABLES = new Set([
  'support_tickets', 'support_messages', 'error_reports', 'user_feedback',
]);

// Tables owned by the exchange user via owner_user_id (not exchange_code)
const EXCHANGE_OWNED = new Set([
  'exchanges',
]);

// ============================================================
// BASE64 HELPERS
// ============================================================
function toB64(bytes: Uint8Array): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}
function fromB64(str: string): Uint8Array {
  const bin = atob(str);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

const enc = new TextEncoder();

// ============================================================
// PASSWORD HASHING (PBKDF2 via Web Crypto — no external deps)
// ============================================================
async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', enc.encode(password), { name: 'PBKDF2' }, false, ['deriveBits']);
  const hash = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' }, key, 256);
  return 'pbkdf2$' + toB64(salt) + '$' + toB64(new Uint8Array(hash));
}

async function verifyPassword(password: string, stored: string): Promise<boolean> {
  if (!stored) return false;
  if (stored.startsWith('pbkdf2$')) {
    const parts = stored.split('$');
    if (parts.length !== 3) return false;
    const salt = fromB64(parts[1]);
    const key = await crypto.subtle.importKey('raw', enc.encode(password), { name: 'PBKDF2' }, false, ['deriveBits']);
    const hash = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' }, key, 256);
    return toB64(new Uint8Array(hash)) === parts[2];
  }
  // Legacy plaintext — compared then upgraded by caller
  return stored === password;
}

// ============================================================
// SESSION TOKENS (HMAC-SHA256, stateless)
// ============================================================
async function signToken(uid: number, role: string): Promise<string> {
  const payload = { uid, r: role, exp: Date.now() + SESSION_TTL_MS };
  const payloadB64 = btoa(JSON.stringify(payload));
  const key = await crypto.subtle.importKey('raw', enc.encode(SUPABASE_SERVICE_KEY), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(payloadB64));
  return payloadB64 + '.' + toB64(new Uint8Array(sig));
}

async function verifyToken(token: string): Promise<{ uid: number; r: string; exp: number } | null> {
  try {
    const [payloadB64, sigB64] = token.split('.');
    if (!payloadB64 || !sigB64) return null;
    const payload = JSON.parse(atob(payloadB64));
    if (!payload || typeof payload.exp !== 'number' || payload.exp < Date.now()) return null;
    const key = await crypto.subtle.importKey('raw', enc.encode(SUPABASE_SERVICE_KEY), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
    const valid = await crypto.subtle.verify('HMAC', key, fromB64(sigB64), enc.encode(payloadB64));
    return valid ? payload : null;
  } catch {
    return null;
  }
}

// ============================================================
// AUDIT LOG
// ============================================================
async function audit(admin: any, entry: Record<string, any>): Promise<void> {
  try {
    await admin.from('audit_logs').insert({
      user_id: entry.user_id ?? null,
      user_name: entry.user_name ?? 'system',
      user_type: entry.user_type ?? null,
      action: entry.action,
      entity_type: entry.entity_type ?? null,
      entity_id: entry.entity_id ? String(entry.entity_id) : null,
      description: entry.description ?? null,
      status: entry.status ?? 'success',
    });
  } catch {
    // never fail the request because of audit
  }
}

// ============================================================
// RATE LIMIT (login attempts via audit_logs)
// ============================================================
async function countRecentFailures(admin: any, identifier: string): Promise<number> {
  const since = new Date(Date.now() - LOCK_WINDOW_MS).toISOString();
  const { count } = await admin
    .from('audit_logs')
    .select('*', { count: 'exact', head: true })
    .eq('action', 'login_failed')
    .eq('user_name', identifier)
    .gte('created_at', since);
  return count || 0;
}

// ============================================================
// SESSION USER RESOLUTION
// ============================================================
async function getSessionUser(body: any, admin: any, req?: any) {
  // ── Try Supabase HMAC token first ──
  if (admin) {
    const token = body.auth_token;
    if (token && !token.startsWith('google_') && !token.startsWith('local_token_')) {
      const payload = await verifyToken(token);
      if (payload) {
        const { data: user } = await admin.from('users').select('*').eq('id', payload.uid).maybeSingle();
        if (user && user.status === 'active') {
          delete user.password;
          if (user.role === 'exchange') {
            const { data: ex } = await admin.from('exchanges').select('exchange_code').eq('owner_user_id', user.id).maybeSingle();
            user._exchange_code = ex?.exchange_code || '';
          }
          if (user.role === 'customer') {
            const { data: cust } = await admin.from('customers').select('exchange_code').eq('mobile', user.mobile).maybeSingle();
            user._exchange_code = cust?.exchange_code || '';
          }
          return user;
        }
      }
    }
  }

  // ── Fallback: Base44 SDK auth (for users logged in via platform auth) ──
  // Try createClientFromRequest first, then fall back to explicit token
  const b44Token: string = body.base44_token || '';
  const sdkClients: any[] = [];
  if (req) {
    try {
      const { createClientFromRequest } = await import('npm:@base44/sdk@0.8.49');
      sdkClients.push(createClientFromRequest(req));
    } catch { /* Base44 SDK not available in standalone mode */ }
  }
  if (b44Token) {
    try {
      const { createClient } = await import('npm:@base44/sdk@0.8.49');
      sdkClients.push(createClient({
        appId: Deno.env.get('BASE44_APP_ID') || '',
        token: b44Token,
        requiresAuth: false,
      }));
    } catch { /* ignore */ }
  }
  for (const c of sdkClients) {
    try {
      const b44User = await c.auth.me();
      if (b44User) {
        const email = (b44User.email || '').toLowerCase().trim();
        const creatorEmail = (Deno.env.get('CREATOR_EMAIL') || '').toLowerCase();
      const isCreator = (creatorEmail && email === creatorEmail) || b44User.role === 'admin';
        if (isCreator) {
          return {
            id: b44User.id,
            full_name: b44User.full_name || 'Creator',
            email,
            username: email,
            mobile: null,
            role: 'creator',
            status: 'active',
            _exchange_code: '',
            _isBase44Admin: true,
          };
        }
      }
    } catch { /* try next client */ }
  }

  return null;
}

// ============================================================
// ROW MAPPER — strip sensitive fields, normalize timestamps
// ============================================================
function mapRow(row: any) {
  if (!row) return null;
  const mapped = { ...row };
  if (mapped.id !== undefined && mapped.id !== null) mapped.id = String(mapped.id);
  if (mapped.created_at) mapped.created_date = mapped.created_at;
  if (mapped.updated_at) mapped.updated_date = mapped.updated_at;
  delete mapped.password;
  return mapped;
}

function mapField(field: string): string {
  if (field === 'created_date') return 'created_at';
  if (field === 'updated_date') return 'updated_at';
  return field;
}

// ============================================================
// CUSTOMER ROW FILTER (server-side self-scoping)
// ============================================================
function isCustomerRow(row: any, user: any): boolean {
  const mobile = user.mobile;
  const name = user.full_name;
  // conversions: customer_mobile or customer_name
  if (row.customer_mobile && row.customer_mobile === mobile) return true;
  if (row.customer_name && row.customer_name === name) return true;
  // transfers: sender_phone, receiver_name, receiver_phone
  if (row.sender_phone && row.sender_phone === mobile) return true;
  if (row.receiver_name && row.receiver_name === name) return true;
  if (row.receiver_phone && row.receiver_phone === mobile) return true;
  // rates: allowed if show_to_customer
  if (row.show_to_customer === true) return true;
  return false;
}

// Lazy init of admin client (avoids crash when SERVICE_KEY unset)
let SUPABASE_URL = '';
let SUPABASE_KEY = '';
let SUPABASE_SERVICE_KEY = '';
let _admin: any = null;

export default async function (req: Request): Promise<Response> {
  try {
    SUPABASE_URL = Deno.env.get('SUPABASE_URL') || '';
    SUPABASE_KEY = Deno.env.get('SUPABASE_KEY') || '';
    SUPABASE_SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_KEY') || '';

    if (!SUPABASE_URL || !SUPABASE_KEY) {
      return Response.json({ error: 'Supabase secrets not configured' }, { status: 500 });
    }

    _admin = SUPABASE_SERVICE_KEY ? createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY) : null;
    const anon = createClient(SUPABASE_URL, SUPABASE_KEY);

    const body = await req.json().catch(() => ({}));
    const { action } = body;

    // ============================================================
    // KEEPALIVE (open — system health check, no auth required)
    // Light query to prevent Supabase free-tier inactivity pause.
    // Does NOT modify any data — only reads one row + logs to audit_logs.
    // ============================================================
    if (action === 'keepalive') {
      try {
        const start = Date.now();
        // Lightest possible query — read a single id from users table
        const { error } = await anon.from('users').select('id').limit(1);
        const latencyMs = Date.now() - start;
        if (error) {
          return Response.json({
            success: false,
            error: error.message,
            timestamp: new Date().toISOString(),
          });
        }
        // Log to audit_logs (separate from financial data)
        if (_admin) {
          try {
            await _admin.from('audit_logs').insert({
              user_name: 'system_keepalive',
              user_type: 'system',
              action: 'keepalive',
              description: `KeepAlive ping — latency ${latencyMs}ms`,
              status: 'success',
            });
          } catch { /* non-critical */ }
        }
        const now = new Date();
        const nextRun = new Date(now.getTime() + 6 * 24 * 60 * 60 * 1000); // +6 days
        return Response.json({
          success: true,
          timestamp: now.toISOString(),
          latency_ms: latencyMs,
          next_run: nextRun.toISOString(),
          interval_days: 6,
        });
      } catch (e: any) {
        return Response.json({
          success: false,
          error: e.message,
          timestamp: new Date().toISOString(),
        });
      }
    }

    // ============================================================
    // TEST CONNECTION (open)
    // ============================================================
    if (action === 'test') {
      try {
        const { data, error } = await anon.from('users').select('id').limit(1);
        if (error) return Response.json({ connected: false, error: error.message, url: SUPABASE_URL });
        return Response.json({ connected: true, url: SUPABASE_URL, message: 'Connection successful' });
      } catch (e: any) {
        return Response.json({ connected: false, error: e.message, url: SUPABASE_URL });
      }
    }

    // ============================================================
    // BOOTSTRAP ADMIN (open — one-time setup)
    // ============================================================
    if (action === 'bootstrapAdmin') {
      if (!_admin) return Response.json({ success: false, error: 'SUPABASE_SERVICE_KEY not configured on server' });
      const { data: existing } = await _admin.from('users').select('id').eq('username', 'admin').maybeSingle();
      if (existing) return Response.json({ success: true, message: 'admin already exists', user_id: existing.id });
      const creatorPwd = Deno.env.get('CREATOR_PASSWORD') || '';
      if (!creatorPwd) return Response.json({ success: false, error: 'CREATOR_PASSWORD secret not configured' });
      const hash = await hashPassword(creatorPwd);
      const { data, error } = await _admin.from('users').insert({
        full_name: 'System Creator', username: 'admin', email: (Deno.env.get('CREATOR_EMAIL') || 'creator@example.com'), password: hash, role: 'creator', status: 'active',
      }).select().single();
      if (error) return Response.json({ success: false, error: error.message });
      await audit(_admin, { user_name: 'admin', user_type: 'admin', action: 'create', entity_type: 'user', entity_id: data.id, description: 'Bootstrap admin created' });
      return Response.json({ success: true, message: 'admin created', user_id: data.id });
    }

    // ============================================================
    // LOGIN (open — rate-limited)
    // ============================================================
    if (action === 'login') {
      const { identifier, password } = body;
      if (!identifier || !password) return Response.json({ success: false, error: 'missing_fields' });

      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      // Rate limit
      const fails = await countRecentFailures(_admin, identifier);
      if (fails >= LOCK_MAX_FAILS) {
        return Response.json({ success: false, error: 'too_many_attempts' });
      }

      // Look up by username, mobile, or email
      let { data: user } = await _admin.from('users').select('*').eq('username', identifier).maybeSingle();
      if (!user) {
        const r2 = await _admin.from('users').select('*').eq('mobile', identifier).maybeSingle();
        user = r2.data;
      }
      if (!user) {
        const r3 = await _admin.from('users').select('*').eq('email', identifier.toLowerCase().trim()).maybeSingle();
        user = r3.data;
      }
      if (!user) {
        await audit(_admin, { user_name: identifier, action: 'login_failed', description: 'user not found' });
        return Response.json({ success: false, error: 'user_not_found' });
      }

      const ok = await verifyPassword(password, user.password || '');
      if (!ok) {
        await audit(_admin, { user_name: identifier, action: 'login_failed', entity_id: user.id, description: 'wrong password' });
        return Response.json({ success: false, error: 'wrong_password' });
      }
      if (user.status !== 'active') {
        await audit(_admin, { user_id: user.id, user_name: identifier, user_type: user.role, action: 'login_failed', description: 'user inactive' });
        return Response.json({ success: false, error: 'user_inactive' });
      }

      // Upgrade legacy plaintext password to hash
      if (!(user.password || '').startsWith('pbkdf2$')) {
        const newHash = await hashPassword(password);
        await _admin.from('users').update({ password: newHash }).eq('id', user.id);
      }

      await _admin.from('users').update({ last_login: new Date().toISOString() }).eq('id', user.id);

      // Resolve exchange
      let exchange = null;
      if (user.role === 'exchange') {
        const { data: exData } = await _admin.from('exchanges').select('*').eq('owner_user_id', user.id).maybeSingle();
        exchange = exData;
      }

      const token = await signToken(user.id, user.role);
      await audit(_admin, { user_id: user.id, user_name: user.full_name, user_type: user.role, action: 'login', description: 'User logged in' });

      // Strip password before returning
      const safeUser = { ...user };
      delete safeUser.password;

      return Response.json({ success: true, user: safeUser, exchange, token });
    }

    // ============================================================
    // REGISTER CUSTOMER (open — self-registration)
    // ============================================================
    if (action === 'registerCustomer') {
      const { full_name, mobile, username, password, email } = body;
      if (!full_name || !mobile || !username || !password) return Response.json({ success: false, error: 'missing_fields' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      const { data: existingMobile } = await _admin.from('users').select('id').eq('mobile', mobile).maybeSingle();
      if (existingMobile) return Response.json({ success: false, error: 'mobile_exists' });

      const { data: existingUsername } = await _admin.from('users').select('id').eq('username', username).maybeSingle();
      if (existingUsername) return Response.json({ success: false, error: 'username_exists' });

      const insertData: any = {
        full_name, mobile, username, password: await hashPassword(password), role: 'customer', status: 'active',
      };
      if (email && email.trim()) insertData.email = email.trim();

      let { data, error: insertError } = await _admin.from('users').insert(insertData).select().single();
      // If email column doesn't exist, retry without it
      if (insertError && email && email.trim() && /email/.test(insertError.message || '')) {
        delete insertData.email;
        const retry = await _admin.from('users').insert(insertData).select().single();
        data = retry.data;
        insertError = retry.error;
      }
      if (insertError) return Response.json({ success: false, error: insertError.message });

      const token = await signToken(data.id, data.role);
      await audit(_admin, { user_id: data.id, user_name: full_name, user_type: 'customer', action: 'create', entity_type: 'user', entity_id: data.id, description: 'Customer self-registered' });

      const safeUser = { ...data };
      delete safeUser.password;
      return Response.json({ success: true, user: safeUser, token });
    }

    // ============================================================
    // REGISTER EXCHANGE (open — self-registration by sarraaf)
    // ============================================================
    if (action === 'registerExchange') {
      const { exchange_name, full_name, mobile, username, password, email, country, city } = body;
      if (!exchange_name || !full_name || !mobile || !username || !password) return Response.json({ success: false, error: 'missing_fields' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      // Duplicate checks — mobile and username must be unique across ALL users
      const { data: existingMobile } = await _admin.from('users').select('id').eq('mobile', mobile).maybeSingle();
      if (existingMobile) return Response.json({ success: false, error: 'mobile_exists' });

      const { data: existingUsername } = await _admin.from('users').select('id').eq('username', username).maybeSingle();
      if (existingUsername) return Response.json({ success: false, error: 'username_exists' });

      // Auto-generate exchange code: EX-XXXXX (5 random digits, check uniqueness)
      let exchangeCode = '';
      for (let attempt = 0; attempt < 10; attempt++) {
        const num = Math.floor(10000 + Math.random() * 90000);
        exchangeCode = `EX-${num}`;
        const { data: existingCode } = await _admin.from('exchanges').select('id').eq('exchange_code', exchangeCode).maybeSingle();
        if (!existingCode) break;
      }

      const insertData: any = {
        full_name, mobile, username, password: await hashPassword(password), role: 'exchange', status: 'active',
      };
      if (email && email.trim()) insertData.email = email.trim();

      let { data: newUser, error: userErr } = await _admin.from('users').insert(insertData).select().single();
      // If email column doesn't exist, retry without it
      if (userErr && email && email.trim() && /email/.test(userErr.message || '')) {
        delete insertData.email;
        const retry = await _admin.from('users').insert(insertData).select().single();
        newUser = retry.data;
        userErr = retry.error;
      }
      if (userErr) return Response.json({ success: false, error: userErr.message });

      const exchangeInsert: any = {
        exchange_code: exchangeCode,
        exchange_name,
        owner_user_id: newUser.id,
        status: 'active',
      };
      if (country) exchangeInsert.country = country;
      if (city) exchangeInsert.city = city;

      let { data: newExchange, error: exErr } = await _admin.from('exchanges').insert(exchangeInsert).select().single();
      // If country/city columns don't exist, retry without them
      if (exErr && (country || city) && /country|city/.test(exErr.message || '')) {
        delete exchangeInsert.country;
        delete exchangeInsert.city;
        const retry = await _admin.from('exchanges').insert(exchangeInsert).select().single();
        newExchange = retry.data;
        exErr = retry.error;
      }
      if (exErr) {
        await _admin.from('users').delete().eq('id', newUser.id);
        return Response.json({ success: false, error: exErr.message });
      }

      const token = await signToken(newUser.id, newUser.role);
      await audit(_admin, { user_id: newUser.id, user_name: full_name, user_type: 'exchange', action: 'create', entity_type: 'exchange', entity_id: newExchange.id, description: `Exchange self-registered: ${exchangeCode} (${exchange_name})` });

      const safeUser = { ...newUser };
      delete safeUser.password;
      return Response.json({ success: true, user: safeUser, exchange: mapRow(newExchange), token });
    }

    // ============================================================
    // GOOGLE LOGIN (open — no password needed, Google verifies identity)
    // ============================================================
    if (action === 'googleLogin') {
      const { google_email, google_name } = body;
      if (!google_email) return Response.json({ success: false, error: 'missing_fields' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      // Look up user by email
      let { data: user } = await _admin.from('users').select('*').eq('email', google_email).maybeSingle();

      if (user) {
        if (user.status !== 'active') {
          return Response.json({ success: false, error: 'user_inactive' });
        }
        await _admin.from('users').update({ last_login: new Date().toISOString() }).eq('id', user.id);

        let exchange = null;
        if (user.role === 'exchange') {
          const { data: exData } = await _admin.from('exchanges').select('*').eq('owner_user_id', user.id).maybeSingle();
          exchange = exData;
        }

        const token = await signToken(user.id, user.role);
        await audit(_admin, { user_id: user.id, user_name: user.full_name, user_type: user.role, action: 'login', description: 'Google login' });

        const safeUser = { ...user };
        delete safeUser.password;
        return Response.json({ success: true, user: safeUser, exchange, token });
      }

      // No existing user — create a new customer with Google email
      const baseName = google_name || (google_email.split('@')[0] || 'user');
      let username = google_email.split('@')[0] || 'user';
      // Ensure username uniqueness
      let attempt = 0;
      while (attempt < 20) {
        const { data: existingU } = await _admin.from('users').select('id').eq('username', username).maybeSingle();
        if (!existingU) break;
        attempt++;
        username = (google_email.split('@')[0] || 'user') + '_' + Math.floor(Math.random() * 10000);
      }

      // Generate unique placeholder mobile for Google-only users
      const placeholderMobile = 'g_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      const randomPass = crypto.randomUUID();
      const hashedPass = await hashPassword(randomPass);

      const insertData: any = {
        full_name: baseName,
        email: google_email,
        username,
        mobile: placeholderMobile,
        password: hashedPass,
        role: 'customer',
        status: 'active',
      };

      const { data: newUser, error: createErr } = await _admin.from('users').insert(insertData).select().single();

      if (createErr) return Response.json({ success: false, error: createErr.message, detail: JSON.stringify(createErr) });

      const token = await signToken(newUser.id, newUser.role);
      await audit(_admin, { user_id: newUser.id, user_name: newUser.full_name, user_type: 'customer', action: 'create', entity_type: 'user', entity_id: newUser.id, description: 'Customer registered via Google' });

      const safeUser = { ...newUser };
      delete safeUser.password;
      return Response.json({ success: true, user: safeUser, token });
    }

    // ============================================================
    // LINK GOOGLE ACCOUNT (open — for password recovery)
    // User enters mobile → authenticates with Google → email is linked
    // ============================================================
    if (action === 'linkGoogleAccount') {
      const { mobile, google_email } = body;
      if (!mobile || !google_email) return Response.json({ success: false, error: 'missing_fields' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      // Find user by mobile
      const { data: user } = await _admin.from('users').select('*').eq('mobile', mobile).maybeSingle();
      if (!user) return Response.json({ success: false, error: 'user_not_found' });

      // Check if email already used by another user
      const { data: existingEmail } = await _admin.from('users').select('id').eq('email', google_email).neq('id', user.id).maybeSingle();
      if (existingEmail) return Response.json({ success: false, error: 'email_exists' });

      const { error: updateError } = await _admin.from('users').update({ email: google_email }).eq('id', user.id);
      if (updateError) return Response.json({ success: false, error: updateError.message });

      await audit(_admin, { user_id: user.id, user_name: user.full_name, user_type: user.role, action: 'update', entity_type: 'user', entity_id: user.id, description: 'Google account linked for password recovery' });

      const safeUser = { ...user, email: google_email };
      delete safeUser.password;
      return Response.json({ success: true, user: safeUser, message: 'Google account linked successfully' });
    }

    // ============================================================
    // SUPABASE AUTH — email verification (open, no app auth required)
    // Frontend cannot use supabase-js directly (VITE_ secrets are not
    // exposed in the browser), so these proxy through the anon client.
    // ============================================================
    // ============================================================
    // CUSTOM OTP — independent email verification (no Supabase Auth)
    // ============================================================
    // ============================================================
    // CUSTOM OTP — uses existing app_settings table (no new table needed)
    // Format: key=otp_<email>, value=code|expires_at|attempts|verified
    // ============================================================
    function otpKey(email: string): string {
      return 'otp_' + email.toLowerCase().trim();
    }
    function packOtp(code: string, expiresAt: string, attempts: number, verified: boolean): string {
      return [code, expiresAt, String(attempts), verified ? '1' : '0'].join('|');
    }
    function unpackOtp(value: string): { code: string; expiresAt: string; attempts: number; verified: boolean } | null {
      if (!value) return null;
      const parts = value.split('|');
      if (parts.length < 4) return null;
      return { code: parts[0], expiresAt: parts[1], attempts: Number(parts[2]) || 0, verified: parts[3] === '1' };
    }

    // ============================================================
    // EMAIL VERIFICATION — uses Supabase's built-in email OTP
    // Free tier: sends 6-digit code to ANY email (4/hour limit)
    // No external service or API key needed.
    // ============================================================
    // ============================================================
    // EMAIL VERIFICATION — uses Supabase's built-in email OTP
    // Rate limit: 1 email per email address per 4 hours
    // ============================================================
    const OTP_RATE_LIMIT_MS = 4 * 60 * 60 * 1000; // 4 hours
    function otpSentKey(email: string): string {
      return 'otp_sent_' + email.toLowerCase().trim();
    }

    async function checkOtpRateLimit(emailNorm: string): Promise<boolean> {
      if (!_admin) return false;
      const { data: row } = await _admin.from('app_settings')
        .select('setting_value, updated_at')
        .eq('setting_key', otpSentKey(emailNorm))
        .maybeSingle();
      if (row?.updated_at && new Date(row.updated_at).getTime() > Date.now() - OTP_RATE_LIMIT_MS) {
        return false; // rate limited
      }
      return true;
    }

    async function markOtpSent(emailNorm: string): Promise<void> {
      if (!_admin) return;
      await _admin.from('app_settings')
        .upsert({
          setting_key: otpSentKey(emailNorm),
          setting_value: new Date().toISOString(),
          setting_type: 'text',
          description: 'otp_sent_timestamp',
        }, { onConflict: 'setting_key' });
    }

    if (action === 'auth_signup') {
      const { email, password } = body;
      if (!email || !password) return Response.json({ success: false, error: 'missing_fields' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      const emailNorm = email.toLowerCase().trim();

      // Check if email already registered in users table
      const { data: existing } = await _admin.from('users').select('id').eq('email', emailNorm).maybeSingle();
      if (existing) return Response.json({ success: false, error: 'email_exists' });

      // Rate limit: 1 email per 4 hours
      const allowed = await checkOtpRateLimit(emailNorm);
      if (!allowed) return Response.json({ success: false, error: 'rate_limit', message: 'برای ارسال مجدد کد، ۴ ساعت صبر کنید.' });

      // Send OTP via Supabase's built-in email service (free)
      const { error: otpErr } = await anon.auth.signInWithOtp({
        email: emailNorm,
        options: {
          shouldCreateUser: true,
          emailRedirectTo: getEmailRedirectUrl(req),
        },
      });
      if (otpErr) {
        return Response.json({ success: false, error: otpErr.message });
      }

      await markOtpSent(emailNorm);
      return Response.json({ success: true, message: 'کد تأیید به ایمیل ارسال شد' });
    }

    if (action === 'auth_verifyOtp') {
      const { email, token } = body;
      if (!email || !token) return Response.json({ success: false, error: 'missing_fields' });

      const emailNorm = email.toLowerCase().trim();
      const { data, error } = await anon.auth.verifyOtp({
        email: emailNorm,
        token: String(token).trim(),
        type: 'email',
      });
      if (error) return Response.json({ success: false, error: error.message });

      return Response.json({ success: true, message: 'ایمیل تأیید شد' });
    }

    if (action === 'auth_resend') {
      const { email } = body;
      if (!email) return Response.json({ success: false, error: 'missing_fields' });

      const emailNorm = email.toLowerCase().trim();

      // Rate limit: 1 email per 4 hours
      const allowed = await checkOtpRateLimit(emailNorm);
      if (!allowed) return Response.json({ success: false, error: 'rate_limit', message: 'برای ارسال مجدد کد، ۴ ساعت صبر کنید.' });

      const { error: otpErr } = await anon.auth.signInWithOtp({
        email: emailNorm,
        options: {
          shouldCreateUser: true,
          emailRedirectTo: getEmailRedirectUrl(req),
        },
      });
      if (otpErr) return Response.json({ success: false, error: otpErr.message });

      await markOtpSent(emailNorm);
      return Response.json({ success: true, message: 'کد جدید ارسال شد' });
    }
    if (action === 'auth_recover') {
      const { code } = body;
      if (!code) return Response.json({ success: false, error: 'missing_fields' });
      const { data, error } = await anon.auth.exchangeCodeForSession(code);
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, session: data.session, user: data.user });
    }
    if (action === 'auth_updateUser') {
      const { access_token, new_password } = body;
      if (!access_token || !new_password) return Response.json({ success: false, error: 'missing_fields' });
      const userClient = createClient(SUPABASE_URL, SUPABASE_KEY, {
        auth: { persistSession: false },
        global: { headers: { Authorization: `Bearer ${access_token}` } },
      });
      const { data, error } = await userClient.auth.updateUser({ password: new_password });
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, data });
    }
    if (action === 'auth_signOut') {
      const { access_token } = body;
      if (access_token) {
        const userClient = createClient(SUPABASE_URL, SUPABASE_KEY, {
          auth: { persistSession: false },
          global: { headers: { Authorization: `Bearer ${access_token}` } },
        });
        await userClient.auth.signOut();
      }
      return Response.json({ success: true });
    }

    // ============================================================
    // AUTH REQUIRED — everything below
    // ============================================================
    const authUser = await getSessionUser(body, _admin, req);
    if (!authUser) return Response.json({ error: 'unauthorized' }, { status: 401 });

    const role = authUser.role;

    // ============================================================
    // LOGOUT
    // ============================================================
    if (action === 'logout') {
      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'logout', description: 'User logged out' });
      return Response.json({ success: true });
    }

    // GET ME — resolve user info from HMAC token (creator sessions: info not in localStorage)
    if (action === 'getMe') {
      return Response.json({ success: true, user: mapRow(authUser) });
    }

    // ============================================================
    // CHANGE PASSWORD (auth required)
    // ============================================================
    if (action === 'changePassword') {
      const { old_password, new_password } = body;
      if (!old_password || !new_password) return Response.json({ success: false, error: 'missing_fields' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      const { data: fullUser } = await _admin.from('users').select('id, password').eq('id', authUser.id).maybeSingle();
      if (!fullUser) return Response.json({ success: false, error: 'user_not_found' });

      const ok = await verifyPassword(old_password, fullUser.password || '');
      if (!ok) {
        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'change_password', status: 'failed', description: 'Wrong current password' });
        return Response.json({ success: false, error: 'wrong_password' });
      }

      const newHash = await hashPassword(new_password);
      const { error: updateError } = await _admin.from('users').update({ password: newHash }).eq('id', authUser.id);
      if (updateError) return Response.json({ success: false, error: updateError.message });

      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'change_password', description: 'Password changed' });
      return Response.json({ success: true });
    }

    // ============================================================
    // LIST USERS (creator only)
    // ============================================================
    const creatorEmail = (Deno.env.get('CREATOR_EMAIL') || '').toLowerCase();
    const isCreator = role === 'creator' || role === 'admin' || (creatorEmail && (authUser.email === creatorEmail || authUser.username === creatorEmail));
    if (action === 'listUsers') {
      if (!isCreator) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      const { data, error } = await _admin.from('users').select('id, full_name, mobile, username, email, role, status, last_login, created_at').order('id', { ascending: false });
      if (error) return Response.json({ success: false, error: error.message });
      const mapped = (data || []).map((u: any) => ({ ...u, id: String(u.id), created_date: u.created_at }));
      return Response.json({ success: true, users: mapped });
    }

    // ============================================================
    // LIST EXCHANGES (creator only)
    // ============================================================
    if (action === 'listExchanges') {
      if (!isCreator) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      const { data, error } = await _admin.from('exchanges').select('*').order('id', { ascending: false });
      if (error) return Response.json({ success: false, error: error.message });
      const mapped = (data || []).map(mapRow);
      return Response.json({ success: true, exchanges: mapped });
    }

    // ============================================================
    // CREATE EXCHANGE (creator only)
    // ============================================================
    if (action === 'createExchange') {
      const { full_name, exchange_name, mobile, username, password, exchange_code } = body;
      if (!full_name || !exchange_name || !mobile || !username || !password || !exchange_code) return Response.json({ success: false, error: 'missing_fields' });
      if (role !== 'creator') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      const { data: existingMobile } = await _admin.from('users').select('id').eq('mobile', mobile).maybeSingle();
      if (existingMobile) return Response.json({ success: false, error: 'mobile_exists' });
      const { data: existingUsername } = await _admin.from('users').select('id').eq('username', username).maybeSingle();
      if (existingUsername) return Response.json({ success: false, error: 'username_exists' });
      const { data: existingCode } = await _admin.from('exchanges').select('id').eq('exchange_code', exchange_code).maybeSingle();
      if (existingCode) return Response.json({ success: false, error: 'exchange_code_exists' });

      const hash = await hashPassword(password);
      const { data: newUser, error: userErr } = await _admin.from('users').insert({
        full_name, mobile, username, password: hash, role: 'exchange', status: 'active',
      }).select().single();
      if (userErr) return Response.json({ success: false, error: userErr.message });

      const { data: newExchange, error: exErr } = await _admin.from('exchanges').insert({
        exchange_code, exchange_name, owner_user_id: newUser.id, status: 'active',
      }).select().single();
      if (exErr) {
        await _admin.from('users').delete().eq('id', newUser.id);
        return Response.json({ success: false, error: exErr.message });
      }

      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'create', entity_type: 'exchange', entity_id: newExchange.id, description: `Created exchange ${exchange_code} (${exchange_name})` });
      return Response.json({ success: true, user: { ...newUser, id: String(newUser.id), password: undefined }, exchange: mapRow(newExchange) });
    }

    // ============================================================
    // AMOUNT VALIDATION — server-side check for financial fields
    // ============================================================
    const POSITIVE_AMOUNT_FIELDS: Record<string, string[]> = {
      transfers: ['amount'],
      conversions: ['from_amount', 'to_amount', 'rate'],
      treasury_transactions: ['amount'],
      bank_transactions: ['amount'],
      wallet_transactions: ['amount'],
      charge_orders: ['amount'],
      rates: ['buy_rate', 'sell_rate'],
    };
    const NON_NEGATIVE_AMOUNT_FIELDS: Record<string, string[]> = {
      documents: ['amount', 'fee'],
      journal_entries: ['amount'],
      ledger_entries: ['debit', 'credit'],
    };

    function validateAmountFields(table: string, data: Record<string, any>): string | null {
      const positive = POSITIVE_AMOUNT_FIELDS[table];
      if (positive) {
        for (const f of positive) {
          const v = data[f];
          if (v === undefined || v === null) continue; // NOT NULL handled by DB
          const n = Number(v);
          if (isNaN(n) || n <= 0) return `invalid_amount_${f}`;
        }
      }
      const nonNeg = NON_NEGATIVE_AMOUNT_FIELDS[table];
      if (nonNeg) {
        for (const f of nonNeg) {
          const v = data[f];
          if (v === undefined || v === null) continue;
          const n = Number(v);
          if (isNaN(n) || n < 0) return `invalid_amount_${f}`;
        }
      }
      return null;
    }

    // ============================================================
    // GENERIC CRUD (auth + tenant isolation)
    // ============================================================

    // Helper: strip columns that don't exist in the table schema
    // Catches "Could not find the 'X' column" errors and retries
    async function safeInsert(admin: any, table: string, insertData: any) {
      try {
        const { data: result, error } = await admin.from(table).insert(insertData).select().single();
        if (error) throw error;
        return { result, error: null };
      } catch (e: any) {
        const msg = e.message || '';
        const match = msg.match(/Could not find the '(\w+)' column/);
        if (match) {
          const badCol = match[1];
          const cleaned = { ...insertData };
          delete cleaned[badCol];
          // Retry recursively until no more unknown columns
          return safeInsert(admin, table, cleaned);
        }
        return { result: null, error: e };
      }
    }

    async function safeUpdate(admin: any, table: string, id: any, updateData: any) {
      try {
        const { data: result, error } = await admin.from(table).update(updateData).eq('id', id).select().single();
        if (error) throw error;
        return { result, error: null };
      } catch (e: any) {
        const msg = e.message || '';
        const match = msg.match(/Could not find the '(\w+)' column/);
        if (match) {
          const badCol = match[1];
          const cleaned = { ...updateData };
          delete cleaned[badCol];
          return safeUpdate(admin, table, id, cleaned);
        }
        return { result: null, error: e };
      }
    }

    if (action === 'crud') {
      const { table, operation, filters, data, id, sort, limit } = body;
      if (!table || !operation) return Response.json({ success: false, error: 'missing_table_or_operation' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      // Customer restrictions
      if (role === 'customer') {
        if (operation !== 'select') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
        if (!CUSTOMER_READ_TABLES.has(table)) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      }

      // Build tenant-scoped filters
      const effFilters: Record<string, any> = { ...(filters || {}) };
      const exCode = authUser._exchange_code;
      if (role === 'exchange' && EXCHANGE_SCOPED.has(table) && exCode) {
        effFilters.exchange_code = exCode;
      }
      if (role === 'customer' && CUSTOMER_READ_TABLES.has(table)) {
        // Security: always scope wallets and personal tables by user_id,
        // even when the customer has no exchange_code (self-registered).
        if (table === 'wallets') effFilters.user_id = authUser.id;
        if (table === 'charge_orders') effFilters.created_by_id = authUser.id;
        if (table === 'customer_notifications') effFilters.customer_user_id = authUser.id;
        if (table === 'customer_transfer_requests') effFilters.user_id = authUser.id;
        if (table === 'customer_links') effFilters.user_id = authUser.id;
        if (table === 'wallet_transactions') effFilters.user_id = authUser.id;
        if (exCode) {
          effFilters.exchange_code = exCode;
          if (table === 'rates') effFilters.show_to_customer = true;
        }
      }

      // ---- SELECT ----
      if (operation === 'select') {
        let query = _admin.from(table).select('*');
        for (const [key, value] of Object.entries(effFilters)) {
          if (value !== undefined && value !== null && value !== '') {
            query = query.eq(mapField(key), value);
          }
        }
        if (sort) {
          if (sort.startsWith('-')) query = query.order(mapField(sort.slice(1)), { ascending: false });
          else query = query.order(mapField(sort), { ascending: true });
        } else {
          query = query.order('id', { ascending: false });
        }
        if (limit) query = query.limit(Number(limit));

        const { data: result, error } = await query;
        if (error) return Response.json({ success: false, error: error.message });

        let mapped = (result || []).map(mapRow);

        // Customer self-scoping (post-filter)
        if (role === 'customer' && (table === 'conversions' || table === 'transfers')) {
          mapped = mapped.filter((row: any) => isCustomerRow(row, authUser));
        }

        return Response.json({ success: true, result: mapped });
      }

      // ---- INSERT (with idempotency via client_operation_id) ----
      if (operation === 'insert') {
        // Enforce 4-safe limit per exchange
        if (table === 'safes' && role === 'exchange') {
          const { count: safeCount } = await _admin.from('safes')
            .select('*', { count: 'exact', head: true })
            .eq('exchange_code', exCode);
          if ((safeCount || 0) >= 4) {
            return Response.json({ success: false, error: 'max_safes_reached', message: 'هر صراف نهایتاً می‌تواند ۴ صندوق ایجاد کند.' });
          }
        }
        const { client_operation_id } = body;
        const insertData = { ...data };

        // Idempotency: if client_operation_id provided, atomically claim the key
        if (client_operation_id) {
          try {
            // INSERT ... ON CONFLICT DO NOTHING — atomic claim via UNIQUE constraint
            const { data: claimed, error: claimErr } = await _admin
              .from('idempotency_keys')
              .insert({
                client_operation_id,
                table_name: table,
                result_id: -1, // placeholder, updated after insert
                created_at: new Date().toISOString(),
              })
              .select()
              .maybeSingle();
            if (claimErr && /duplicate|23505/i.test(claimErr.message || '')) {
              // Already processed by a concurrent request — fetch and return original result
              const { data: existing } = await _admin
                .from('idempotency_keys')
                .select('result_id')
                .eq('client_operation_id', client_operation_id)
                .maybeSingle();
              if (existing?.result_id && existing.result_id > 0) {
                const { data: origResult } = await _admin.from(table).select('*').eq('id', existing.result_id).maybeSingle();
                if (origResult) {
                  return Response.json({ success: true, result: mapRow(origResult), idempotent: true });
                }
              }
              // Key exists but result not ready — reject duplicate to prevent double-processing
              return Response.json({ success: false, error: 'duplicate_operation_in_progress' });
            }
            // If insert succeeded (new row), proceed with the actual data insert below
          } catch {
            // idempotency_keys table may not exist — continue without idempotency
          }
        }

        // Amount validation
        const amountErr = validateAmountFields(table, insertData);
        if (amountErr) return Response.json({ success: false, error: amountErr });

        // Force tenant + audit fields for exchange role
        if (role === 'exchange' && EXCHANGE_SCOPED.has(table) && exCode) {
          insertData.exchange_code = exCode;
        }
        // Creator needs a default exchange_code for tenant-scoped tables
        if ((role === 'creator' || role === 'admin') && EXCHANGE_SCOPED.has(table) && !insertData.exchange_code) {
          insertData.exchange_code = body.exchange_code || 'CREATOR';
        }

        // Auto-generate transfer_number for transfers table
        if (table === 'transfers' && !insertData.transfer_number) {
          insertData.transfer_number = 'TR-' + Date.now().toString(36).toUpperCase();
        }
        if (HAS_REGISTERED_BY.has(table)) {
          insertData.registered_by = String(authUser.id);
        }

        const { result: insResult, error: insError } = await safeInsert(_admin, table, insertData);
        if (insError) return Response.json({ success: false, error: insError.message });

        // Update idempotency key with the real result_id (was placeholder -1 during claim)
        if (client_operation_id) {
          try {
            await _admin.from('idempotency_keys')
              .update({ result_id: insResult.id })
              .eq('client_operation_id', client_operation_id);
          } catch {
            // idempotency_keys table may not exist — ignore
          }
        }

        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'create', entity_type: table, entity_id: insResult.id, description: `Created ${table}` });
        return Response.json({ success: true, result: mapRow(insResult) });
      }

      // ---- BULK INSERT ----
      if (operation === 'bulkInsert') {
        const records = Array.isArray(data) ? data : [data];
        const enriched = records.map((r: any) => {
          const row = { ...r };
          if (role === 'exchange' && EXCHANGE_SCOPED.has(table) && exCode) row.exchange_code = exCode;
          if (HAS_REGISTERED_BY.has(table)) row.registered_by = String(authUser.id);
          return row;
        });
        // Use safeInsert for each record to handle unknown columns
        const results: any[] = [];
        const errors: string[] = [];
        for (const rec of enriched) {
          const { result: insResult, error: insError } = await safeInsert(_admin, table, rec);
          if (insError) {
            errors.push(insError.message);
          } else if (insResult) {
            results.push(insResult);
          }
        }
        if (results.length === 0 && errors.length > 0) {
          return Response.json({ success: false, error: errors[0] });
        }
        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'create', entity_type: table, description: `Bulk insert ${results.length} ${table}` });
        const mapped = results.map(mapRow);
        return Response.json({ success: true, result: mapped });
      }

      // ---- UPDATE ----
      if (operation === 'update') {
        // Ownership check — exchange-scoped tables (filter by exchange_code)
        if (EXCHANGE_SCOPED.has(table) && role === 'exchange') {
          const { data: row } = await _admin.from(table).select('exchange_code').eq('id', id).maybeSingle();
          if (!row || row.exchange_code !== exCode) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
        }
        // Ownership check — exchange-owned tables (filter by owner_user_id)
        if (EXCHANGE_OWNED.has(table) && role === 'exchange') {
          const { data: row } = await _admin.from(table).select('owner_user_id').eq('id', id).maybeSingle();
          if (!row || String(row.owner_user_id) !== String(authUser.id)) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
        }
        if (role === 'customer') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });

        // Amount validation
        const amountErr = validateAmountFields(table, data);
        if (amountErr) return Response.json({ success: false, error: amountErr });

        const updateData = { ...data };
        delete updateData.id;
        delete updateData.created_date;
        delete updateData.updated_date;
        delete updateData.exchange_code; // never allow moving across tenants
        updateData.updated_at = new Date().toISOString();

        const { result: updResult, error: updError } = await safeUpdate(_admin, table, id, updateData);
        if (updError) return Response.json({ success: false, error: updError.message });
        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'update', entity_type: table, entity_id: id, description: `Updated ${table}` });
        return Response.json({ success: true, result: mapRow(updResult) });
      }

      // ---- DELETE ----
      if (operation === 'delete') {
        if (EXCHANGE_SCOPED.has(table) && role === 'exchange') {
          const { data: row } = await _admin.from(table).select('exchange_code').eq('id', id).maybeSingle();
          if (!row || row.exchange_code !== exCode) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
        }
        if (EXCHANGE_OWNED.has(table) && role === 'exchange') {
          const { data: row } = await _admin.from(table).select('owner_user_id').eq('id', id).maybeSingle();
          if (!row || String(row.owner_user_id) !== String(authUser.id)) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
        }
        if (role === 'customer') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });

        const { error } = await _admin.from(table).delete().eq('id', id);
        if (error) return Response.json({ success: false, error: error.message });
        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'delete', entity_type: table, entity_id: id, description: `Deleted ${table}` });
        return Response.json({ success: true });
      }

      return Response.json({ success: false, error: 'unknown_crud_operation' });
    }

    // ============================================================
    // UPLOAD FILE (auth required — uploads to Supabase Storage)
    // ============================================================
    if (action === 'uploadFile') {
      if (!authUser) return Response.json({ success: false, error: 'unauthorized' }, { status: 401 });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      const { file_data, file_name, content_type } = body;
      if (!file_data || !file_name) return Response.json({ success: false, error: 'missing_file' });

      try {
        // Decode base64
        const bytes = Uint8Array.from(atob(file_data), c => c.charCodeAt(0));
        // Ensure 'public' bucket exists (create if missing, ignore if exists)
        await _admin.storage.createBucket('public', { public: true }).catch(() => {});
        // Upload to Supabase Storage
        const filePath = `receipts/${Date.now()}_${file_name}`;
        const { data, error: upErr } = await _admin.storage
          .from('public')
          .upload(filePath, bytes, { contentType: content_type || 'image/jpeg', upsert: false });
        if (upErr) return Response.json({ success: false, error: upErr.message });
        const { data: urlData } = _admin.storage.from('public').getPublicUrl(data.path);
        return Response.json({ success: true, result: { file_url: urlData.publicUrl } });
      } catch (e: any) {
        return Response.json({ success: false, error: e.message });
      }
    }

    // ============================================================
    // PAYMENT GATEWAY (auth required — feature is in "updating" status)
    // ============================================================
    if (action === 'createPaymentIntent') {
      // Feature disabled — returns "updating" status
      return Response.json({ success: false, error: 'feature_disabled', message: 'درگاه بانکی در حال راه‌اندازی است. پرداخت آنلاین فعلاً ممکن نیست.' });
    }

    if (action === 'verifyPayment') {
      return Response.json({ success: false, error: 'feature_disabled', message: 'درگاه بانکی در حال راه‌اندازی است.' });
    }

    if (action === 'listGateways') {
      if (!['creator', 'admin'].includes(role)) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      const { data: gateways, error } = await _admin.from('bank_gateways').select('*').order('display_order', { ascending: true });
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, gateways: (gateways || []).map(mapRow) });
    }

    if (action === 'saveGateway') {
      if (!['creator', 'admin'].includes(role)) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      const { gateway_data, gateway_id } = body;
      if (!gateway_data || !gateway_data.gateway_key || !gateway_data.name) return Response.json({ success: false, error: 'missing_fields' });

      const cleanData = { ...gateway_data };
      delete cleanData.id;
      delete cleanData.created_at;
      delete cleanData.updated_at;
      // Never store actual secrets — only the reference
      delete cleanData.secret_key;
      delete cleanData.api_key;
      delete cleanData.private_key;
      cleanData.updated_at = new Date().toISOString();

      if (gateway_id) {
        const { data, error } = await _admin.from('bank_gateways').update(cleanData).eq('id', gateway_id).select().single();
        if (error) return Response.json({ success: false, error: error.message });
        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'update', entity_type: 'bank_gateways', entity_id: data.id, description: `Updated gateway ${gateway_data.gateway_key}` });
        return Response.json({ success: true, gateway: mapRow(data) });
      } else {
        cleanData.active = false; // new gateways always start disabled
        cleanData.status = cleanData.status || 'configured';
        const { data, error } = await _admin.from('bank_gateways').insert(cleanData).select().single();
        if (error) return Response.json({ success: false, error: error.message });
        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'create', entity_type: 'bank_gateways', entity_id: data.id, description: `Created gateway ${gateway_data.gateway_key}` });
        return Response.json({ success: true, gateway: mapRow(data) });
      }
    }

    if (action === 'toggleGateway') {
      if (!['creator', 'admin'].includes(role)) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      const { gateway_id, active } = body;
      if (!gateway_id) return Response.json({ success: false, error: 'missing_gateway_id' });

      // Check feature status — prevent activation while "updating"
      const { data: feature } = await _admin.from('feature_settings').select('status').eq('feature_key', 'payment_gateway').maybeSingle();
      if (feature?.status === 'updating' && active) {
        return Response.json({ success: false, error: 'feature_updating', message: 'درگاه بانکی در حال راه‌اندازی است. فعال‌سازی فعلاً ممکن نیست.' });
      }

      const { data, error } = await _admin.from('bank_gateways').update({ active, status: active ? 'active' : 'disabled', updated_at: new Date().toISOString() }).eq('id', gateway_id).select().single();
      if (error) return Response.json({ success: false, error: error.message });
      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'update', entity_type: 'bank_gateways', entity_id: gateway_id, description: `Gateway ${active ? 'activated' : 'disabled'}: ${data.gateway_key}` });
      return Response.json({ success: true, gateway: mapRow(data) });
    }

    if (action === 'listPaymentTransactions') {
      if (!['creator', 'admin'].includes(role)) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      const { data: txs, error } = await _admin.from('payment_transactions').select('*').order('id', { ascending: false }).limit(100);
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, transactions: (txs || []).map(mapRow) });
    }

    // ============================================================
    // SUPPORT SYSTEM — tickets, messages, error reports, feedback
    // ============================================================
    // user_id columns are BIGINT in Supabase (users.id = BIGSERIAL).
    // Base44 SDK auth returns a UUID string as authUser.id — we must
    // only write user_id when it's a valid numeric ID from the Supabase
    // users table.  This helper centralises that guard.
    function numericUserId(u: any): number | null {
      if (!u || !u.id) return null;
      const n = Number(u.id);
      return !isNaN(n) && n > 0 ? n : null;
    }

    if (action === 'support_createTicket') {
      if (!authUser) return Response.json({ success: false, error: 'unauthorized' }, { status: 401 });
      const { subject, description, category, priority } = body;
      if (!subject) return Response.json({ success: false, error: 'missing_subject' });

      const ticketNumber = `TKT-${Date.now().toString(36).toUpperCase()}`;
      const insertData: any = {
        ticket_number: ticketNumber,
        subject,
        description: description || '',
        category: category || 'general',
        priority: priority || 'normal',
        status: 'open',
      };
      const uid = numericUserId(authUser);
      if (uid) insertData.user_id = uid;
      // exchange_code is taken from the verified session, never from the client
      if (authUser._exchange_code) insertData.exchange_code = authUser._exchange_code;

      const { data: result, error } = await _admin.from('support_tickets').insert(insertData).select().single();
      if (error) return Response.json({ success: false, error: error.message });
      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'create', entity_type: 'support_tickets', entity_id: result.id, description: `Created ticket ${ticketNumber}` });
      return Response.json({ success: true, result: mapRow(result) });
    }

    if (action === 'support_listTickets') {
      if (!authUser) return Response.json({ success: false, error: 'unauthorized' }, { status: 401 });
      let query = _admin.from('support_tickets').select('*');
      if (role === 'creator' || role === 'admin') {
        // all tickets
      } else if (role === 'exchange') {
        query = query.eq('exchange_code', exCode);
      } else {
        // customer — only own tickets; user_id is BIGINT so skip filter
        // if the caller's id is a non-numeric Base44 UUID (returns empty)
        const uid = numericUserId(authUser);
        if (uid) query = query.eq('user_id', uid);
        else query = query.eq('user_id', -1); // impossible match
      }
      const { data: result, error } = await query.order('id', { ascending: false }).limit(200);
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, result: (result || []).map(mapRow) });
    }

    if (action === 'support_updateTicketStatus') {
      if (!authUser) return Response.json({ success: false, error: 'unauthorized' }, { status: 401 });
      const { status, assigned_to } = body;
      const ticket_id = Number(body.ticket_id);
      if (!ticket_id || !status) return Response.json({ success: false, error: 'missing_fields' });
      if (role !== 'creator' && role !== 'admin') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });

      const updateData: any = { status, updated_at: new Date().toISOString() };
      if (assigned_to !== undefined) updateData.assigned_to = assigned_to;

      const { data: result, error } = await _admin.from('support_tickets').update(updateData).eq('id', ticket_id).select().single();
      if (error) return Response.json({ success: false, error: error.message });
      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'update', entity_type: 'support_tickets', entity_id: ticket_id, description: `Ticket status → ${status}` });
      return Response.json({ success: true, result: mapRow(result) });
    }

    if (action === 'support_addMessage') {
      if (!authUser) return Response.json({ success: false, error: 'unauthorized' }, { status: 401 });
      const { message, attachment_url } = body;
      const ticket_id = Number(body.ticket_id);
      if (!ticket_id || !message) return Response.json({ success: false, error: 'missing_fields' });

      // Verify the caller has access to this ticket
      const { data: ticket } = await _admin.from('support_tickets').select('id, user_id, exchange_code').eq('id', ticket_id).maybeSingle();
      if (!ticket) return Response.json({ success: false, error: 'ticket_not_found' });
      if (role !== 'creator' && role !== 'admin') {
        if (role === 'exchange' && ticket.exchange_code !== authUser._exchange_code) {
          return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
        }
        // For non-exchange users compare numeric user_id
        const uid = numericUserId(authUser);
        if (!uid || Number(ticket.user_id) !== uid) {
          return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
        }
      }

      const insertData: any = {
        ticket_id,
        sender_name: authUser.full_name || '',
        message,
      };
      const senderUid = numericUserId(authUser);
      if (senderUid) insertData.sender_id = senderUid;
      if (attachment_url) insertData.attachment_url = attachment_url;

      const { data: result, error } = await _admin.from('support_messages').insert(insertData).select().single();
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, result: mapRow(result) });
    }

    if (action === 'support_listMessages') {
      if (!authUser) return Response.json({ success: false, error: 'unauthorized' }, { status: 401 });
      const ticket_id = Number(body.ticket_id);
      if (!ticket_id) return Response.json({ success: false, error: 'missing_ticket_id' });

      // Verify access to the ticket
      const { data: ticket } = await _admin.from('support_tickets').select('id, user_id, exchange_code').eq('id', ticket_id).maybeSingle();
      if (!ticket) return Response.json({ success: false, error: 'ticket_not_found' });
      if (role !== 'creator' && role !== 'admin') {
        if (role === 'exchange' && ticket.exchange_code !== authUser._exchange_code) {
          return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
        }
        const uid = numericUserId(authUser);
        if (!uid || Number(ticket.user_id) !== uid) {
          return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
        }
      }

      const { data: result, error } = await _admin.from('support_messages').select('*').eq('ticket_id', ticket_id).order('id', { ascending: true }).limit(500);
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, result: (result || []).map(mapRow) });
    }

    if (action === 'support_reportError') {
      // Public — no auth required; user_id/exchange_code derived from
      // session if present, never from the client body (anti-spoof).
      const { error_type, error_message, stack_trace, device, app_version } = body;
      if (!error_type) return Response.json({ success: false, error: 'missing_error_type' });

      const insertData: any = {
        error_type,
        error_message: error_message || '',
        stack_trace: stack_trace || '',
        device: device || '',
        app_version: app_version || '1.0.0',
        status: 'new',
      };
      if (authUser) {
        const uid = numericUserId(authUser);
        if (uid) insertData.user_id = uid;
        if (authUser._exchange_code) insertData.exchange_code = authUser._exchange_code;
      }

      const { data: result, error } = await _admin.from('error_reports').insert(insertData).select().single();
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, result: mapRow(result) });
    }

    if (action === 'support_listErrors') {
      if (!authUser) return Response.json({ success: false, error: 'unauthorized' }, { status: 401 });
      if (role !== 'creator' && role !== 'admin') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      const { data: result, error } = await _admin.from('error_reports').select('*').order('id', { ascending: false }).limit(500);
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, result: (result || []).map(mapRow) });
    }

    if (action === 'support_submitFeedback') {
      if (!authUser) return Response.json({ success: false, error: 'unauthorized' }, { status: 401 });
      const { type, message, rating } = body;
      if (!message) return Response.json({ success: false, error: 'missing_message' });

      const insertData: any = {
        type: type || 'suggestion',
        message,
        rating: rating || 0,
        status: 'new',
      };
      const uid = numericUserId(authUser);
      if (uid) insertData.user_id = uid;
      // exchange_code from verified session only
      if (authUser._exchange_code) insertData.exchange_code = authUser._exchange_code;

      const { data: result, error } = await _admin.from('user_feedback').insert(insertData).select().single();
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, result: mapRow(result) });
    }

    if (action === 'support_listFeedback') {
      if (!authUser) return Response.json({ success: false, error: 'unauthorized' }, { status: 401 });
      if (role !== 'creator' && role !== 'admin') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      const { data: result, error } = await _admin.from('user_feedback').select('*').order('id', { ascending: false }).limit(500);
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, result: (result || []).map(mapRow) });
    }

    // ============================================================
    // LEDGER — Atomic document posting (double-entry)
    // All financial operations go directly to Supabase via RPC.
    // No localStorage caching for financial data.
    // ============================================================
    if (action === 'postDocument') {
      const { doc_type, currency, amount, fee, related_type, related_id,
              related_name, description, lines, transfer_id, client_operation_id } = body;
      if (!doc_type || !currency || !lines || !Array.isArray(lines) || lines.length === 0) {
        return Response.json({ success: false, error: 'missing_fields' });
      }
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      // Validate double-entry balance per currency
      const byCurrency: Record<string, { debit: number; credit: number }> = {};
      for (const line of lines) {
        const cur = line.currency || currency;
        if (!byCurrency[cur]) byCurrency[cur] = { debit: 0, credit: 0 };
        byCurrency[cur].debit += Number(line.debit || 0);
        byCurrency[cur].credit += Number(line.credit || 0);
      }
      for (const [cur, val] of Object.entries(byCurrency)) {
        if (Math.abs(val.debit - val.credit) > 0.01) {
          return Response.json({ success: false, error: `unbalanced_entry_${cur}`, detail: `debit=${val.debit} credit=${val.credit}` });
        }
      }

      try {
        const docExchangeCode = (role === 'creator' || role === 'admin') && body.exchange_code
          ? body.exchange_code
          : (authUser._exchange_code || '');
        if (!docExchangeCode) return Response.json({ success: false, error: 'no_exchange_code', message: 'حساب صرافی شما فاقد کد صرافی است.' });
        // ── Idempotency check ──
        if (client_operation_id) {
          try {
            const { data: existing } = await _admin.from('idempotency_keys')
              .select('result_id').eq('client_operation_id', client_operation_id).maybeSingle();
            if (existing?.result_id && existing.result_id > 0) {
              const { data: origResult } = await _admin.from('documents').select('*').eq('id', existing.result_id).maybeSingle();
              if (origResult) return Response.json({ success: true, result: mapRow(origResult), idempotent: true });
            }
          } catch { /* idempotency_keys table may not exist */ }
        }

        // ── Generate doc number ──
        let docNumber = '';
        const { data: lastDoc } = await _admin.from('documents')
          .select('doc_number').eq('exchange_code', docExchangeCode)
          .order('id', { ascending: false }).limit(1).maybeSingle();
        if (lastDoc?.doc_number) {
          const match = lastDoc.doc_number.match(/^DOC-(\d+)$/);
          const nextNum = match ? parseInt(match[1], 10) + 1 : 1;
          docNumber = 'DOC-' + String(nextNum).padStart(6, '0');
        } else {
          docNumber = 'DOC-000001';
        }

        // ── Insert document header ──
        const docInsert: any = {
          doc_number: docNumber,
          exchange_code: docExchangeCode,
          doc_type,
          amount: Number(amount) || 0,
          currency,
          fee: Number(fee) || 0,
          related_type: related_type || 'none',
          related_id: related_id || null,
          related_name: related_name || '',
          description: description || '',
          registered_by: authUser.full_name || '',
        };
        const uid = numericUserId(authUser);
        if (uid) docInsert.registered_by_user_id = uid;
        if (transfer_id) docInsert.transfer_id = transfer_id;

        const { data: docRow, error: docErr } = await _admin.from('documents').insert(docInsert).select().single();
        if (docErr) return Response.json({ success: false, error: docErr.message });
        const docId = docRow.id;

        // ── Insert ledger lines ──
        const lineRecords = lines.map((line: any, idx: number) => ({
          exchange_code: docExchangeCode,
          document_id: docId,
          transfer_id: transfer_id || null,
          type: doc_type,
          account_type: line.account_type || 'suspense',
          account_id: line.account_id || '',
          account_name: line.account_name || '',
          currency: line.currency || currency,
          debit: Number(line.debit) || 0,
          credit: Number(line.credit) || 0,
          rate: line.rate ? Number(line.rate) : null,
          pair_entry_id: line.pair_entry_id || null,
          description: line.description || description || '',
          doc_line_no: line.line_no || (idx + 1),
          registered_by: authUser.full_name || '',
          registered_by_user_id: uid || null,
        }));

        const { error: lineErr } = await _admin.from('ledger_entries').insert(lineRecords);
        if (lineErr) {
          // Rollback document if lines fail
          await _admin.from('documents').delete().eq('id', docId);
          return Response.json({ success: false, error: lineErr.message });
        }

        // ── Record idempotency key ──
        if (client_operation_id) {
          try {
            await _admin.from('idempotency_keys').insert({
              client_operation_id, table_name: 'documents', result_id: docId,
            });
          } catch { /* ignore */ }
        }

        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'create', entity_type: 'documents', entity_id: docId, description: `Posted document ${docNumber} (${doc_type})` });
        return Response.json({ success: true, result: { document_id: docId, doc_number: docNumber, idempotent: false } });
      } catch (e: any) {
        return Response.json({ success: false, error: e.message });
      }
    }

    // ============================================================
    // LEDGER — Atomic transfer posting (transfer + document + lines)
    // ============================================================
    if (action === 'postTransfer') {
      const { direction, sender_name, sender_phone, receiver_name, receiver_phone,
              destination, origin, amount, currency, rate, fee, fee_currency,
              description, client_operation_id } = body;
      if (!direction || !sender_name || !receiver_name || !amount || !currency) {
        return Response.json({ success: false, error: 'missing_fields' });
      }
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      try {
        const transferExchangeCode = (role === 'creator' || role === 'admin') && body.exchange_code
          ? body.exchange_code
          : (authUser._exchange_code || '');
        const { data: result, error: rpcError } = await _admin.rpc('post_transfer_transaction', {
          p_exchange_code: transferExchangeCode,
          p_direction: direction,
          p_sender_name: sender_name,
          p_sender_phone: sender_phone || '',
          p_receiver_name: receiver_name,
          p_receiver_phone: receiver_phone || '',
          p_destination: destination || '',
          p_origin: origin || '',
          p_amount: Number(amount),
          p_currency: currency,
          p_rate: rate ? Number(rate) : null,
          p_fee: Number(fee) || 0,
          p_fee_currency: fee_currency || null,
          p_description: description || '',
          p_registered_by: authUser.full_name || '',
          p_doc_type: 'transfer',
          p_user_id: numericUserId(authUser),
          p_client_operation_id: client_operation_id || null,
        });
        if (rpcError) return Response.json({ success: false, error: rpcError.message });
        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'create', entity_type: 'transfers', entity_id: result.transfer_id, description: `Posted transfer ${result.transfer_number}` });
        return Response.json({ success: true, result });
      } catch (e: any) {
        return Response.json({ success: false, error: e.message });
      }
    }

    // ============================================================
    // LEDGER — Reverse document (soft-delete + reversal entries)
    // ============================================================
    if (action === 'reverseDocument') {
      const { document_id, reason } = body;
      if (!document_id) return Response.json({ success: false, error: 'missing_document_id' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      const revExchangeCode = (role === 'creator' || role === 'admin') && body.exchange_code
        ? body.exchange_code
        : (authUser._exchange_code || '');
      // Ownership check
      if (role === 'exchange') {
        const { data: row } = await _admin.from('documents').select('exchange_code').eq('id', document_id).maybeSingle();
        if (!row || row.exchange_code !== revExchangeCode) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      }
      if (role === 'customer') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });

      try {
        const { data: result, error: rpcError } = await _admin.rpc('reverse_document_transaction', {
          p_exchange_code: revExchangeCode,
          p_document_id: Number(document_id),
          p_registered_by: authUser.full_name || '',
          p_reason: reason || 'بدون دلیل',
        });
        if (rpcError) return Response.json({ success: false, error: rpcError.message });
        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'delete', entity_type: 'documents', entity_id: document_id, description: `Reversed document ${document_id}` });
        return Response.json({ success: true, result });
      } catch (e: any) {
        return Response.json({ success: false, error: e.message });
      }
    }

    // ============================================================
    // LEDGER — Edit document (soft-delete old lines + insert new)
    // ============================================================
    if (action === 'editDocument') {
      const { document_id, description, amount, currency, edit_note, new_lines } = body;
      if (!document_id || !new_lines || !Array.isArray(new_lines)) {
        return Response.json({ success: false, error: 'missing_fields' });
      }
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      const editExchangeCode = (role === 'creator' || role === 'admin') && body.exchange_code
        ? body.exchange_code
        : (authUser._exchange_code || '');
      // Ownership check
      if (role === 'exchange') {
        const { data: row } = await _admin.from('documents').select('exchange_code').eq('id', document_id).maybeSingle();
        if (!row || row.exchange_code !== editExchangeCode) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      }
      if (role === 'customer') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });

      // Validate double-entry balance per currency (tolerance 0.01)
      const editByCurrency: Record<string, { debit: number; credit: number }> = {};
      for (const line of new_lines) {
        const cur = line.currency || currency || '';
        if (!cur) continue;
        if (!editByCurrency[cur]) editByCurrency[cur] = { debit: 0, credit: 0 };
        editByCurrency[cur].debit += Number(line.debit || 0);
        editByCurrency[cur].credit += Number(line.credit || 0);
      }
      for (const [cur, val] of Object.entries(editByCurrency)) {
        if (Math.abs(val.debit - val.credit) > 0.01) {
          return Response.json({ success: false, error: `unbalanced_entry_${cur}`, detail: `debit=${val.debit} credit=${val.credit}` });
        }
      }

      try {
        const { data: result, error: rpcError } = await _admin.rpc('edit_document_transaction', {
          p_exchange_code: editExchangeCode,
          p_document_id: Number(document_id),
          p_description: description || '',
          p_amount: Number(amount) || 0,
          p_currency: currency || '',
          p_edit_note: edit_note || '',
          p_new_lines: new_lines,
          p_registered_by: authUser.full_name || '',
          p_user_id: numericUserId(authUser),
        });
        if (rpcError) return Response.json({ success: false, error: rpcError.message });
        await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'update', entity_type: 'documents', entity_id: document_id, description: `Edited document ${document_id}` });
        return Response.json({ success: true, result });
      } catch (e: any) {
        return Response.json({ success: false, error: e.message });
      }
    }

    // ============================================================
    // LEDGER — Get balances (from SQL views, never from cache)
    // ============================================================
    if (action === 'getBalances') {
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      const { balance_type, account_id, currency } = body;
      const exCode = (role === 'creator' || role === 'admin') && body.exchange_code
        ? body.exchange_code
        : (authUser._exchange_code || '');

      try {
        if (balance_type === 'treasury') {
          const { data, error } = await _admin.from('v_treasury_balances')
            .select('*').eq('exchange_code', exCode);
          if (error) return Response.json({ success: false, error: error.message });
          return Response.json({ success: true, balances: data });
        }
        if (balance_type === 'bank') {
          const { data, error } = await _admin.from('v_bank_balances')
            .select('*').eq('exchange_code', exCode);
          if (error) return Response.json({ success: false, error: error.message });
          return Response.json({ success: true, balances: data });
        }
        if (balance_type === 'customer') {
          const { data, error } = await _admin.from('v_customer_balances')
            .select('*').eq('exchange_code', exCode);
          if (error) return Response.json({ success: false, error: error.message });
          return Response.json({ success: true, balances: data });
        }
        if (balance_type === 'wallet') {
          const { data, error } = await _admin.from('v_wallet_balances')
            .select('*');
          if (error) return Response.json({ success: false, error: error.message });
          // Customer sees only own wallets
          let filtered = data || [];
          if (role === 'customer') {
            filtered = filtered.filter((w: any) => String(w.user_id) === String(authUser.id));
          } else if (role === 'exchange') {
            filtered = filtered.filter((w: any) => w.exchange_code === exCode);
          }
          return Response.json({ success: true, balances: filtered });
        }
        if (balance_type === 'agent') {
          const { data, error } = await _admin.from('v_agent_balances')
            .select('*').eq('exchange_code', exCode);
          if (error) return Response.json({ success: false, error: error.message });
          return Response.json({ success: true, balances: data });
        }
        if (balance_type === 'profit_loss') {
          const { data, error } = await _admin.from('v_profit_loss')
            .select('*').eq('exchange_code', exCode);
          if (error) return Response.json({ success: false, error: error.message });
          return Response.json({ success: true, balances: data });
        }
        if (balance_type === 'currency') {
          const { data, error } = await _admin.from('v_currency_balances')
            .select('*').eq('exchange_code', exCode);
          if (error) return Response.json({ success: false, error: error.message });
          return Response.json({ success: true, balances: data });
        }
        if (balance_type === 'exchange_summary') {
          const { data, error } = await _admin.from('v_exchange_summary')
            .select('*').eq('exchange_code', exCode);
          if (error) return Response.json({ success: false, error: error.message });
          return Response.json({ success: true, summary: data });
        }
        // Single account balance
        if (balance_type === 'account') {
          const { data: result, error: rpcError } = await _admin.rpc('get_account_balance', {
            p_exchange_code: exCode,
            p_account_type: body.account_type || 'cash',
            p_account_id: String(account_id || ''),
            p_currency: currency || null,
          });
          if (rpcError) return Response.json({ success: false, error: rpcError.message });
          return Response.json({ success: true, balance: result });
        }
        return Response.json({ success: false, error: 'unknown_balance_type' });
      } catch (e: any) {
        return Response.json({ success: false, error: e.message });
      }
    }

    // ============================================================
    // LEDGER — List documents with their ledger lines
    // ============================================================
    if (action === 'listDocuments') {
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      const { filters, sort, limit } = body;
      const effFilters: Record<string, any> = { ...(filters || {}) };
      const exCode = (role === 'creator' || role === 'admin') && body.exchange_code
        ? body.exchange_code
        : (authUser._exchange_code || '');
      if ((role === 'exchange' || role === 'creator' || role === 'admin') && exCode) effFilters.exchange_code = exCode;
      if (role === 'customer') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });

      let query = _admin.from('documents').select('*');
      for (const [key, value] of Object.entries(effFilters)) {
        if (value !== undefined && value !== null && value !== '') {
          query = query.eq(mapField(key), value);
        }
      }
      query = query.order(sort ? mapField(sort.startsWith('-') ? sort.slice(1) : sort) : 'id', { ascending: !sort || !sort.startsWith('-') });
      if (limit) query = query.limit(Number(limit));

      const { data: docs, error } = await query;
      if (error) return Response.json({ success: false, error: error.message });

      // Fetch ledger lines for all documents
      const docIds = (docs || []).map((d: any) => d.id);
      let lines: any[] = [];
      if (docIds.length > 0) {
        const { data: lineData, error: lineErr } = await _admin.from('ledger_entries')
          .select('*').in('document_id', docIds).eq('deleted', false).order('doc_line_no', { ascending: true });
        if (lineErr) return Response.json({ success: false, error: lineErr.message });
        lines = lineData || [];
      }

      const result = (docs || []).map((d: any) => ({
        ...mapRow(d),
        lines: lines.filter((l: any) => l.document_id === d.id).map(mapRow),
      }));
      return Response.json({ success: true, result });
    }

    // ============================================================
    // GET MY EXCHANGE — profile for the logged-in sarraaf
    // ============================================================
    if (action === 'getMyExchange') {
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      try {
        if (role === 'exchange') {
          const { data, error } = await _admin.from('exchanges').select('*').eq('owner_user_id', authUser.id).maybeSingle();
          if (error) return Response.json({ success: false, error: error.message });
          const mapped = mapRow(data);
          if (mapped) mapped.code = mapped.exchange_code || '';
          return Response.json({ success: true, exchange: mapped });
        }
        if (role === 'creator' || role === 'admin') {
          const exCode = body.exchange_code;
          let q = _admin.from('exchanges').select('*');
          if (exCode) q = q.eq('exchange_code', exCode);
          const { data, error } = await q.limit(1).maybeSingle();
          if (error) return Response.json({ success: false, error: error.message });
          const mapped = mapRow(data);
          if (mapped) mapped.code = mapped.exchange_code || '';
          return Response.json({ success: true, exchange: mapped });
        }
        return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      } catch (e: any) {
        return Response.json({ success: false, error: e.message });
      }
    }

    // ============================================================
    // LIST TRANSACTIONS — flat list from v_transactions view
    // ============================================================
    if (action === 'listTransactions') {
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      const { filters, sort, limit } = body;
      const exCode = (role === 'creator' || role === 'admin') && body.exchange_code
        ? body.exchange_code
        : (authUser._exchange_code || '');
      if (role === 'customer') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });

      try {
        // Query documents table directly (v_transactions view may not exist yet)
        let query = _admin.from('documents').select('*');
        if (exCode) query = query.eq('exchange_code', exCode);
        if (filters && typeof filters === 'object') {
          for (const [key, value] of Object.entries(filters)) {
            if (value !== undefined && value !== null && value !== '') {
              query = query.eq(mapField(key), value);
            }
          }
        }
        query = query.order(sort ? mapField(sort.startsWith('-') ? sort.slice(1) : sort) : 'id', { ascending: !sort || !sort.startsWith('-') });
        if (limit) query = query.limit(Number(limit));
        const { data: result, error } = await query;
        if (error) return Response.json({ success: false, error: error.message });
        // Map to transaction format (same columns as v_transactions view)
        const mapped = (result || []).map((d: any) => ({
          id: String(d.id),
          exchange_code: d.exchange_code,
          document_no: d.doc_number,
          type: d.doc_type,
          amount: d.amount,
          currency: d.currency,
          fee: d.fee,
          related_type: d.related_type,
          customer_id: d.related_id ? String(d.related_id) : null,
          customer_name: d.related_name,
          description: d.description,
          registered_by: d.registered_by,
          registered_by_user_id: d.registered_by_user_id,
          transfer_id: d.transfer_id,
          created_at: d.created_at,
          date: d.created_at ? d.created_at.split('T')[0] : null,
          updated_at: d.updated_at,
          deleted: d.deleted || false,
          deleted_date: d.deleted_date || null,
          deleted_by_name: d.deleted_by_name || null,
          edited: d.edited || false,
          edited_date: d.edited_date || null,
          edit_note: d.edit_note || null,
          edited_by_name: d.edited_by_name || null,
          created_date: d.created_at,
          updated_date: d.updated_at,
        }));
        return Response.json({ success: true, result: mapped });
      } catch (e: any) {
        return Response.json({ success: false, error: e.message });
      }
    }

    // ============================================================
    // GET DATABASE SCHEMA (creator only — for emergency backup PDF)
    // Read-only: queries tables via PostgREST + OpenAPI spec.
    // Never modifies any data.
    // ============================================================
    if (action === 'getDatabaseSchema') {
      if (!isCreator) return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      try {
        // Known tables from ENTITY_TABLE_MAP + SQL schema
        const knownTables = [
          'users', 'exchanges', 'customers', 'rates', 'bank_accounts', 'safes',
          'origins', 'transfers', 'documents', 'ledger_entries', 'conversions',
          'treasury_transactions', 'bank_transactions', 'journal_entries',
          'wallets', 'wallet_transactions', 'wallet_topup_requests',
          'wallet_withdrawal_requests', 'charge_orders', 'online_products',
          'sellers', 'packages', 'pricing_plans', 'app_settings',
          'feature_settings', 'rate_settings', 'text_labels', 'rules',
          'customer_notifications', 'customer_transfer_requests', 'customer_links',
          'user_notifications', 'user_permissions', 'user_feedback',
          'support_tickets', 'support_messages', 'error_reports',
          'audit_logs', 'backup_records', 'referrals', 'plan_quotas',
          'quota_change_logs', 'agency_links', 'chat_groups',
          'chat_group_members', 'chat_messages', 'message_reports',
          'bank_gateways', 'payment_transactions', 'payment_records',
          'wallet_bans', 'idempotency_keys',
        ];

        const knownViews = [
          'v_treasury_balances', 'v_bank_balances', 'v_customer_balances',
          'v_wallet_balances', 'v_agent_balances', 'v_profit_loss',
          'v_currency_balances', 'v_exchange_summary', 'v_transactions',
        ];

        // Fetch OpenAPI spec from PostgREST (gives full column info)
        let openApiSpec: any = null;
        try {
          const specRes = await fetch(`${SUPABASE_URL}/rest/v1/`, {
            headers: { 'Accept': 'application/openapi+json' },
          });
          if (specRes.ok) openApiSpec = await specRes.json();
        } catch { /* ignore */ }

        const tables: any[] = [];
        const columns: any[] = [];
        const tableCounts: Record<string, number> = {};

        for (const tableName of knownTables) {
          // Get column info from OpenAPI spec
          let tableCols: string[] = [];
          let colTypes: Record<string, string> = {};
          let colNullable: Record<string, boolean> = {};

          if (openApiSpec?.definitions?.[tableName]?.properties) {
            const props = openApiSpec.definitions[tableName].properties;
            const required = openApiSpec.definitions[tableName].required || [];
            for (const [colName, colInfo] of Object.entries(props)) {
              if (colName === 'id' || colName === 'created_at' || colName === 'updated_at') continue;
              tableCols.push(colName);
              colTypes[colName] = (colInfo as any).format || (colInfo as any).type || 'text';
              colNullable[colName] = !required.includes(colName);
            }
          } else {
            // Fallback: query a sample row to discover columns
            try {
              const { data: sample } = await _admin.from(tableName).select('*').limit(1);
              if (sample && sample.length > 0) {
                tableCols = Object.keys(sample[0]).filter(k => k !== 'id' && k !== 'created_at' && k !== 'updated_at');
              }
            } catch { /* table might not exist */ }
          }

          if (tableCols.length > 0 || openApiSpec?.definitions?.[tableName]) {
            tables.push({ table_name: tableName, table_type: 'BASE TABLE' });
            for (const col of tableCols) {
              columns.push({
                table_name: tableName,
                column_name: col,
                data_type: colTypes[col] || 'text',
                is_nullable: colNullable[col] ? 'YES' : 'NO',
                column_default: null,
                ordinal_position: tableCols.indexOf(col) + 1,
              });
            }
          }

          // Get row count
          try {
            const { count } = await _admin.from(tableName).select('*', { count: 'exact', head: true });
            tableCounts[tableName] = count || 0;
          } catch {
            tableCounts[tableName] = -1;
          }
        }

        // Views — try querying each known view
        const views: any[] = [];
        for (const viewName of knownViews) {
          try {
            const { data: sample } = await _admin.from(viewName).select('*').limit(1);
            const viewCols = sample && sample.length > 0 ? Object.keys(sample[0]) : [];
            views.push({ table_name: viewName, definition: `Columns: ${viewCols.join(', ')}` });
          } catch { /* view might not exist */ }
        }

        // RLS Policies — try pg_policies
        let policies: any[] = [];
        try {
          const { data: polData } = await _admin
            .from('pg_policies')
            .select('tablename, policyname, cmd, qual, with_check')
            .order('tablename');
          policies = polData || [];
        } catch { /* pg_policies not exposed */ }

        // Indexes — try pg_indexes
        let indexes: any[] = [];
        try {
          const { data: idxData } = await _admin
            .from('pg_indexes')
            .select('tablename, indexname, indexdef')
            .order('tablename');
          indexes = idxData || [];
        } catch { /* pg_indexes not exposed */ }

        return Response.json({
          success: true,
          schema: {
            tables,
            columns,
            views,
            constraints: [],
            keyUsage: [],
            indexes,
            policies,
            functions: [],
            tableCounts,
          },
        });
      } catch (e: any) {
        return Response.json({ success: false, error: e.message });
      }
    }

    // ============================================================
    // WALLET WITHDRAWAL — atomic server-side (customer creates request)
    // Balance check + deduction in a single conditional UPDATE (optimistic lock).
    // No client-side balance computation.
    // ============================================================
    if (action === 'createWithdrawalRequest') {
      const { wallet_id, amount, method, destination, description, client_operation_id } = body;
      if (!wallet_id || !amount || !method) return Response.json({ success: false, error: 'missing_fields' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      const amt = Number(amount);
      if (isNaN(amt) || amt <= 0) return Response.json({ success: false, error: 'invalid_amount' });

      // Idempotency check
      if (client_operation_id) {
        try {
          const { data: existing } = await _admin.from('idempotency_keys')
            .select('result_id').eq('client_operation_id', client_operation_id).maybeSingle();
          if (existing?.result_id && existing.result_id > 0) {
            const { data: orig } = await _admin.from('wallet_withdrawal_requests').select('*').eq('id', existing.result_id).maybeSingle();
            if (orig) return Response.json({ success: true, result: mapRow(orig), idempotent: true });
          }
        } catch { /* table may not exist */ }
      }

      // Read wallet
      const { data: wallet } = await _admin.from('wallets').select('*').eq('id', wallet_id).maybeSingle();
      if (!wallet) return Response.json({ success: false, error: 'wallet_not_found' });
      if (role === 'customer' && String(wallet.user_id) !== String(authUser.id)) {
        return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      }

      const currentBalance = Number(wallet.balance || 0);
      const newBalance = currentBalance - amt;
      if (newBalance < 0) return Response.json({ success: false, error: 'insufficient_balance' });

      // Optimistic-lock update (eq on balance prevents concurrent double-spend)
      const { data: updated, error: updErr } = await _admin.from('wallets')
        .update({ balance: newBalance })
        .eq('id', wallet_id)
        .eq('balance', currentBalance)
        .select();
      if (updErr) return Response.json({ success: false, error: updErr.message });
      if (!updated || updated.length === 0) return Response.json({ success: false, error: 'concurrent_modification' });

      // Insert withdrawal request
      const insData: any = {
        wallet_id, amount: amt, currency: wallet.currency || 'AFN',
        method, destination: destination || '', description: description || '',
        status: 'pending',
      };
      const uid = numericUserId(authUser);
      if (uid) insData.user_id = uid;
      if (authUser._exchange_code) insData.exchange_code = authUser._exchange_code;

      const { data: reqRow, error: reqErr } = await _admin.from('wallet_withdrawal_requests').insert(insData).select().single();
      if (reqErr) {
        // Rollback wallet balance
        await _admin.from('wallets').update({ balance: currentBalance }).eq('id', wallet_id);
        return Response.json({ success: false, error: reqErr.message });
      }

      // Record wallet_transaction
      const wtIns: any = {
        wallet_id, type: 'debit', amount: amt, currency: wallet.currency || 'AFN',
        reason: 'withdrawal_request', actor_name: authUser.full_name || '', status: 'pending',
      };
      if (uid) wtIns.user_id = uid;
      if (authUser._exchange_code) wtIns.exchange_code = authUser._exchange_code;
      await _admin.from('wallet_transactions').insert(wtIns).catch(() => {});

      // Record idempotency key
      if (client_operation_id) {
        try {
          await _admin.from('idempotency_keys').insert({
            client_operation_id, table_name: 'wallet_withdrawal_requests', result_id: reqRow.id,
          });
        } catch { /* ignore */ }
      }

      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'create', entity_type: 'wallet_withdrawal_requests', entity_id: reqRow.id, description: `Withdrawal request ${amt} ${wallet.currency}` });
      return Response.json({ success: true, result: mapRow(reqRow) });
    }

    // ============================================================
    // APPROVE / REJECT WITHDRAWAL (exchange/creator — atomic)
    // ============================================================
    if (action === 'approveWithdrawal') {
      const { request_id } = body;
      if (!request_id) return Response.json({ success: false, error: 'missing_request_id' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      if (role === 'customer') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });

      const { data: req } = await _admin.from('wallet_withdrawal_requests').select('*').eq('id', request_id).maybeSingle();
      if (!req) return Response.json({ success: false, error: 'not_found' });
      if (req.status !== 'pending') return Response.json({ success: false, error: 'already_processed' });

      // Post ledger document for the payout (cash/bank out)
      const exCode = (role === 'creator' || role === 'admin') && body.exchange_code
        ? body.exchange_code : (authUser._exchange_code || '');

      const lines = [
        { account_type: 'cash', account_id: '', account_name: 'صندوق', currency: req.currency, debit: 0, credit: Number(req.amount) || 0 },
        { account_type: 'wallet', account_id: String(req.wallet_id), account_name: 'کیف پول', currency: req.currency, debit: Number(req.amount) || 0, credit: 0 },
      ];
      const docRes = await _admin.from('documents').insert({
        doc_number: 'DOC-WD-' + Date.now().toString(36).toUpperCase(),
        exchange_code: exCode, doc_type: 'wallet_withdrawal',
        amount: Number(req.amount) || 0, currency: req.currency,
        related_type: 'wallet', related_id: String(req.wallet_id), related_name: 'برداشت کیف پول',
        description: `برداشت کیف پول - درخواست ${req.id}`, registered_by: authUser.full_name || '',
        registered_by_user_id: numericUserId(authUser),
      }).select().single();
      if (docRes.error) return Response.json({ success: false, error: docRes.error.message });
      const lineRecords = lines.map((l, i) => ({
        exchange_code: exCode, document_id: docRes.data.id, type: 'wallet_withdrawal',
        account_type: l.account_type, account_id: l.account_id, account_name: l.account_name,
        currency: l.currency, debit: l.debit, credit: l.credit, doc_line_no: i + 1,
        registered_by: authUser.full_name || '', registered_by_user_id: numericUserId(authUser),
      }));
      await _admin.from('ledger_entries').insert(lineRecords);

      const { data: updated, error: updErr } = await _admin.from('wallet_withdrawal_requests')
        .update({ status: 'approved', review_date: new Date().toISOString(), reviewer_id: String(authUser.id), reviewer_name: authUser.full_name || '' })
        .eq('id', request_id).eq('status', 'pending').select().single();
      if (updErr) return Response.json({ success: false, error: updErr.message });
      if (!updated) return Response.json({ success: false, error: 'already_processed' });

      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'update', entity_type: 'wallet_withdrawal_requests', entity_id: request_id, description: `Approved withdrawal ${request_id}` });
      return Response.json({ success: true, result: mapRow(updated) });
    }

    if (action === 'rejectWithdrawal') {
      const { request_id, reason } = body;
      if (!request_id) return Response.json({ success: false, error: 'missing_request_id' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      if (role === 'customer') return Response.json({ success: false, error: 'forbidden' }, { status: 403 });

      const { data: req } = await _admin.from('wallet_withdrawal_requests').select('*').eq('id', request_id).maybeSingle();
      if (!req) return Response.json({ success: false, error: 'not_found' });
      if (req.status !== 'pending') return Response.json({ success: false, error: 'already_processed' });

      // Refund the wallet (reverse the deduction)
      const { data: wallet } = await _admin.from('wallets').select('balance').eq('id', req.wallet_id).maybeSingle();
      if (wallet) {
        await _admin.from('wallets').update({ balance: Number(wallet.balance || 0) + Number(req.amount || 0) })
          .eq('id', req.wallet_id).eq('balance', wallet.balance);
      }

      const { data: updated, error: updErr } = await _admin.from('wallet_withdrawal_requests')
        .update({ status: 'rejected', review_date: new Date().toISOString(), reviewer_id: String(authUser.id), reviewer_name: authUser.full_name || '', reject_reason: reason || '' })
        .eq('id', request_id).eq('status', 'pending').select().single();
      if (updErr) return Response.json({ success: false, error: updErr.message });
      if (!updated) return Response.json({ success: false, error: 'already_processed' });

      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'update', entity_type: 'wallet_withdrawal_requests', entity_id: request_id, description: `Rejected withdrawal ${request_id}` });
      return Response.json({ success: true, result: mapRow(updated) });
    }

    if (action === 'listWithdrawals') {
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      let q = _admin.from('wallet_withdrawal_requests').select('*');
      if (role === 'customer') {
        const uid = numericUserId(authUser);
        if (uid) q = q.eq('user_id', uid);
        else q = q.eq('user_id', -1);
      } else if (role === 'exchange' && authUser._exchange_code) {
        q = q.eq('exchange_code', authUser._exchange_code);
      }
      const { data, error } = await q.order('id', { ascending: false }).limit(200);
      if (error) return Response.json({ success: false, error: error.message });
      return Response.json({ success: true, result: (data || []).map(mapRow) });
    }

    // ============================================================
    // CUSTOMER ORDER — atomic (recharge / games / packages)
    // Server-side: validate product, check+deduct wallet, insert order + wallet_transaction
    // ============================================================
    if (action === 'submitCustomerOrder') {
      const { product_id, wallet_id, amount: directAmount, order_type, account_fields, description, client_operation_id } = body;
      if (!wallet_id) return Response.json({ success: false, error: 'missing_fields' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });

      // Idempotency
      if (client_operation_id) {
        try {
          const { data: existing } = await _admin.from('idempotency_keys')
            .select('result_id').eq('client_operation_id', client_operation_id).maybeSingle();
          if (existing?.result_id && existing.result_id > 0) {
            const { data: orig } = await _admin.from('charge_orders').select('*').eq('id', existing.result_id).maybeSingle();
            if (orig) return Response.json({ success: true, result: mapRow(orig), idempotent: true });
          }
        } catch { /* table may not exist */ }
      }

      // Determine price: from product (if product_id) or direct amount
      let price = 0;
      let productKey = order_type || 'manual';
      let productName = order_type || 'سفارش';
      let productCurrency = 'AFN';
      if (product_id) {
        const { data: product } = await _admin.from('online_products').select('*').eq('id', product_id).maybeSingle();
        if (!product || product.enabled === false) return Response.json({ success: false, error: 'product_not_found' });
        price = Number(product.price || 0);
        productKey = product.key || order_type || 'product';
        productName = product.name || 'سفارش';
        productCurrency = product.currency || 'AFN';
      } else {
        price = Number(directAmount || 0);
      }
      if (price <= 0) return Response.json({ success: false, error: 'invalid_product_price' });

      // Read wallet
      const { data: wallet } = await _admin.from('wallets').select('*').eq('id', wallet_id).maybeSingle();
      if (!wallet) return Response.json({ success: false, error: 'wallet_not_found' });
      if (role === 'customer' && String(wallet.user_id) !== String(authUser.id)) {
        return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      }

      const currentBalance = Number(wallet.balance || 0);
      const newBalance = currentBalance - price;
      if (newBalance < 0) return Response.json({ success: false, error: 'insufficient_balance' });

      // Optimistic-lock deduction
      const { data: updated, error: updErr } = await _admin.from('wallets')
        .update({ balance: newBalance }).eq('id', wallet_id).eq('balance', currentBalance).select();
      if (updErr) return Response.json({ success: false, error: updErr.message });
      if (!updated || updated.length === 0) return Response.json({ success: false, error: 'concurrent_modification' });

      // Insert order
      const orderIns: any = {
        product_key: product.key || '', product_name: product.name || '',
        total: price, currency: product.currency || 'AFN',
        paid_currency: (product.currency || 'AFN') === 'IRT' ? 'TOMAN' : (product.currency || 'AFN'),
        total_paid: price, payment_method: 'wallet', wallet_id,
        status: 'pending', fields: account_fields || {}, description: description || '',
      };
      const uid = numericUserId(authUser);
      if (uid) orderIns.user_id = uid;
      if (authUser._exchange_code) orderIns.exchange_code = authUser._exchange_code;

      const { data: orderRow, error: orderErr } = await _admin.from('charge_orders').insert(orderIns).select().single();
      if (orderErr) {
        // Rollback wallet
        await _admin.from('wallets').update({ balance: currentBalance }).eq('id', wallet_id);
        return Response.json({ success: false, error: orderErr.message });
      }

      // Record wallet_transaction
      const wtIns: any = {
        wallet_id, type: 'debit', amount: price, currency: product.currency || 'AFN',
        reason: 'order_payment', actor_name: authUser.full_name || '', status: 'completed',
      };
      if (uid) wtIns.user_id = uid;
      if (authUser._exchange_code) wtIns.exchange_code = authUser._exchange_code;
      await _admin.from('wallet_transactions').insert(wtIns).catch(() => {});

      // Idempotency key
      if (client_operation_id) {
        try {
          await _admin.from('idempotency_keys').insert({
            client_operation_id, table_name: 'charge_orders', result_id: orderRow.id,
          });
        } catch { /* ignore */ }
      }

      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'create', entity_type: 'charge_orders', entity_id: orderRow.id, description: `Order ${product.name} — ${price}` });
      return Response.json({ success: true, result: mapRow(orderRow) });
    }

    // ============================================================
    // CUSTOMER TRANSFER — atomic (wallet deduction + transfer request)
    // ============================================================
    if (action === 'submitCustomerTransfer') {
      const { wallet_id, amount, currency, receiver_name, receiver_phone, destination, description, client_operation_id } = body;
      if (!wallet_id || !amount || !currency || !receiver_name) return Response.json({ success: false, error: 'missing_fields' });
      if (!_admin) return Response.json({ success: false, error: 'server_error' });
      const amt = Number(amount);
      if (isNaN(amt) || amt <= 0) return Response.json({ success: false, error: 'invalid_amount' });

      // Idempotency
      if (client_operation_id) {
        try {
          const { data: existing } = await _admin.from('idempotency_keys')
            .select('result_id').eq('client_operation_id', client_operation_id).maybeSingle();
          if (existing?.result_id && existing.result_id > 0) {
            const { data: orig } = await _admin.from('customer_transfer_requests').select('*').eq('id', existing.result_id).maybeSingle();
            if (orig) return Response.json({ success: true, result: mapRow(orig), idempotent: true });
          }
        } catch { /* table may not exist */ }
      }

      // Read wallet
      const { data: wallet } = await _admin.from('wallets').select('*').eq('id', wallet_id).maybeSingle();
      if (!wallet) return Response.json({ success: false, error: 'wallet_not_found' });
      if (role === 'customer' && String(wallet.user_id) !== String(authUser.id)) {
        return Response.json({ success: false, error: 'forbidden' }, { status: 403 });
      }

      const currentBalance = Number(wallet.balance || 0);
      const newBalance = currentBalance - amt;
      if (newBalance < 0) return Response.json({ success: false, error: 'insufficient_balance' });

      // Optimistic-lock deduction
      const { data: updated, error: updErr } = await _admin.from('wallets')
        .update({ balance: newBalance }).eq('id', wallet_id).eq('balance', currentBalance).select();
      if (updErr) return Response.json({ success: false, error: updErr.message });
      if (!updated || updated.length === 0) return Response.json({ success: false, error: 'concurrent_modification' });

      // Insert transfer request
      const trackingNo = 'CTR-' + Date.now().toString(36).toUpperCase();
      const trIns: any = {
        direction: 'send', currency, amount: amt,
        sender_name: authUser.full_name || '',
        sender_phone: authUser.mobile || '',
        receiver_name, receiver_phone: receiver_phone || '',
        destination: destination || '', description: description || '',
        status: 'pending', transfer_no: trackingNo,
      };
      const uid = numericUserId(authUser);
      if (uid) trIns.user_id = uid;
      if (authUser._exchange_code) trIns.exchange_code = authUser._exchange_code;

      const { data: trRow, error: trErr } = await _admin.from('customer_transfer_requests').insert(trIns).select().single();
      if (trErr) {
        // Rollback wallet
        await _admin.from('wallets').update({ balance: currentBalance }).eq('id', wallet_id);
        return Response.json({ success: false, error: trErr.message });
      }

      // Record wallet_transaction
      const wtIns: any = {
        wallet_id, type: 'debit', amount: amt, currency,
        reason: 'transfer_request', actor_name: authUser.full_name || '', status: 'pending',
      };
      if (uid) wtIns.user_id = uid;
      if (authUser._exchange_code) wtIns.exchange_code = authUser._exchange_code;
      await _admin.from('wallet_transactions').insert(wtIns).catch(() => {});

      // Idempotency key
      if (client_operation_id) {
        try {
          await _admin.from('idempotency_keys').insert({
            client_operation_id, table_name: 'customer_transfer_requests', result_id: trRow.id,
          });
        } catch { /* ignore */ }
      }

      await audit(_admin, { user_id: authUser.id, user_name: authUser.full_name, user_type: role, action: 'create', entity_type: 'customer_transfer_requests', entity_id: trRow.id, description: `Customer transfer ${amt} ${currency}` });
      const result = mapRow(trRow);
      result.tracking_number = trackingNo;
      result.transfer_no = trackingNo;
      return Response.json({ success: true, result });
    }

    return Response.json({ error: 'Unknown action. Use: test, login, registerCustomer, createExchange, changePassword, listUsers, listExchanges, logout, crud, createPaymentIntent, verifyPayment, listGateways, saveGateway, toggleGateway, listPaymentTransactions, support_createTicket, support_listTickets, support_updateTicketStatus, support_addMessage, support_listMessages, support_reportError, support_listErrors, support_submitFeedback, support_listFeedback, postDocument, postTransfer, reverseDocument, editDocument, getBalances, listDocuments, getMyExchange, listTransactions, getDatabaseSchema, createWithdrawalRequest, approveWithdrawal, rejectWithdrawal, listWithdrawals, submitCustomerOrder, submitCustomerTransfer' }, { status: 400 });
  } catch (error: any) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}