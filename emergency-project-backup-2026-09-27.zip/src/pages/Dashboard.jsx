import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTransactions, useCustomers, useSarraafProfile, useFeatures, useTreasuryBalances, useExchangeSummary } from '@/lib/useSarraaf';
import { useAuth } from '@/lib/AuthContext';
import { formatNumber, TX_TYPE_LABELS } from '@/lib/sarraaf';
import { StatCard, EmptyState, LoadingState, TransactionRow } from '@/components/sarraaf/Pieces';
import FeatureGate from '@/components/FeatureGate';
import { getFeatureStatus } from '@/lib/features';
import { getPlanStatus } from '@/lib/permissions';
import { DEFAULT_FREE_QUOTAS } from '@/lib/pricingService';
import CampaignBanner from '@/components/sarraaf/CampaignBanner';
import UsageBar from '@/components/sarraaf/UsageBar';
import { useUpgrade } from '@/lib/UpgradeContext';
import { getAllowedDashboardLinks } from '@/lib/rbac';
import { Card, CardContent } from '@/components/ui/card';
import {
  Users, Send, ArrowLeftRight, ArrowRightLeft, FileText, Banknote, Store, MessageSquareMore,
  Landmark, Coins, TrendingUp, Wallet, Network, Share2, BookOpen, BookCopy,
  ScrollText, Scale, FileSearch, ShoppingBag, CreditCard, Settings, MoreHorizontal, X, Repeat,
  Receipt, Handshake,
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const PRIMARY_LINKS = [
  { label: 'مشتریان', path: '/customers', icon: Users, gradient: 'from-blue-500 to-blue-600' },
  { label: 'خرید/فروش', path: '/trade', icon: Repeat, gradient: 'from-violet-500 to-violet-600' },
  { label: 'داد و گرفت', path: '/dadogereft', icon: Handshake, gradient: 'from-teal-500 to-teal-600' },
  { label: 'صندوق', path: '/cash', icon: Banknote, gradient: 'from-emerald-500 to-emerald-600' },
  { label: 'بانک', path: '/bank', icon: Landmark, gradient: 'from-indigo-500 to-indigo-600' },
  { label: 'حواله', path: '/transfer-book', icon: Send, gradient: 'from-orange-500 to-orange-600' },
  { label: 'تبدیل ارز', path: '/convert', icon: ArrowRightLeft, gradient: 'from-cyan-500 to-cyan-600' },
  { label: 'دریافت', path: '/receipt', icon: Receipt, gradient: 'from-rose-500 to-rose-600' },
  { label: 'گزارش‌ها', path: '/reports', icon: FileText, gradient: 'from-amber-500 to-amber-600' },
];

const SECONDARY_LINKS = [
  { label: 'بازار نرخ', path: '/sarraaf-market', icon: Store, gradient: 'from-cyan-500 to-cyan-600' },
  { label: 'محصولات آنلاین', path: '/online-products', icon: ShoppingBag, gradient: 'from-pink-500 to-pink-600' },
  { label: 'چت صراف‌ها', path: '/sarraaf-chat', icon: MessageSquareMore, gradient: 'from-teal-500 to-teal-600' },
  { label: 'ارز و نرخ', path: '/currencies', icon: Coins, gradient: 'from-amber-500 to-amber-600' },
  { label: 'سود و زیان', path: '/profit-loss', icon: TrendingUp, gradient: 'from-green-500 to-green-600' },
  { label: 'بدهکاران', path: '/debtors', icon: Wallet, gradient: 'from-red-500 to-red-600' },
  { label: 'نمایندگی‌ها', path: '/agents', icon: Network, gradient: 'from-cyan-500 to-cyan-600' },
  { label: 'شبکه نمایندگی', path: '/agency-network', icon: Share2, gradient: 'from-blue-500 to-blue-600' },
  { label: 'دفتر روزنامه', path: '/journal', icon: BookCopy, gradient: 'from-slate-500 to-slate-600' },
  { label: 'دفتر کل', path: '/general-ledger', icon: ScrollText, gradient: 'from-gray-500 to-gray-600' },
  { label: 'ترازنامه', path: '/balance-sheet', icon: Scale, gradient: 'from-stone-500 to-stone-600' },
  { label: 'مغایرت‌گیری', path: '/reconciliation', icon: FileSearch, gradient: 'from-neutral-500 to-neutral-600' },
  { label: 'تنظیمات', path: '/settings', icon: Settings, gradient: 'from-slate-500 to-slate-600' },
];

export default function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useSarraafProfile(user?.id);
  const { data: txs, isLoading: txLoading } = useTransactions();
  const { data: customers, isLoading: custLoading } = useCustomers();
  const { data: features } = useFeatures();
  const { data: treasuryBalances } = useTreasuryBalances();
  const { data: exchangeSummary } = useExchangeSummary();
  const [moreOpen, setMoreOpen] = useState(false);
  const { openUpgrade } = useUpgrade();
  const { toast } = useToast();

  const userRole = user?.role || 'user';
  const primaryLinks = getAllowedDashboardLinks(userRole, PRIMARY_LINKS);
  const secondaryLinks = getAllowedDashboardLinks(userRole, SECONDARY_LINKS);

  const cash = {};
  for (const b of (treasuryBalances || [])) {
    cash[b.currency] = b.balance;
  }
  const afnCash = cash['AFN'] || 0;
  const usdCash = cash['USD'] || 0;
  const today = new Date().toISOString().split('T')[0];
  const todayTxs = (txs || []).filter(t => t.date === today);
  const todayCount = todayTxs.length;

  const quota = profile ? {
    used: profile.quota_used || 0,
    limit: profile.quota_limit || 0,
    remaining: Math.max(0, (profile.quota_limit || 0) - (profile.quota_used || 0)),
  } : null;

  const isFree = !profile || getPlanStatus(profile) === 'free';
  const custCount = customers?.length || 0;
  const todayTransferCount = (txs || []).filter(t => t.date === today && t.type === 'transfer').length;
  const monthTxCount = (txs || []).filter(t => {
    const d = new Date(t.date || t.created_date);
    return d && d.getMonth() === new Date().getMonth();
  }).length;

  const renderLink = (link, isSecondary = false) => {
    const featureKey = link.path.replace('/', '').replace(/-/g, '_');
    const status = getFeatureStatus(features || [], featureKey);
    const isUpdating = status === 'updating';
    const Icon = link.icon;
    return (
      <Link
        key={link.path}
        to={link.path}
        className="flex flex-col items-center gap-2 p-2.5 rounded-xl bg-card border border-border hover:border-primary/30 hover:shadow-card-hover transition-all relative group"
      >
        <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${link.gradient} flex items-center justify-center shadow-sm ${isUpdating ? 'opacity-50' : ''} group-hover:scale-105 transition-transform`}>
          <Icon className="w-5 h-5 text-white" strokeWidth={2.2} />
        </div>
        <span className="text-[11px] font-medium text-center leading-tight text-foreground">{link.label}</span>
        {isUpdating && (
          <span className="absolute -top-1 -left-1 px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[8px] font-bold">
            به‌روزرسانی
          </span>
        )}
      </Link>
    );
  };

  return (
    <FeatureGate featureKey="dashboard">
      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-2.5 mb-5">
        <StatCard label="معاملات امروز" value={txLoading ? '...' : formatNumber(todayCount)} icon={ArrowLeftRight} gradient="from-blue-500 to-blue-600" />
        <StatCard label="حواله امروز" value={txLoading ? '...' : formatNumber(todayTransferCount)} icon={Send} gradient="from-emerald-500 to-emerald-600" />
        <StatCard label="مشتریان" value={custLoading ? '...' : formatNumber(customers?.length || 0)} icon={Users} gradient="from-amber-500 to-amber-600" />
      </div>

      {/* Primary Quick Links */}
      <div className="flex items-center justify-between mb-2.5">
        <h3 className="text-sm font-bold text-foreground">دسترسی سریع</h3>
      </div>
      <div className="grid grid-cols-3 gap-2.5 mb-4">
        {primaryLinks.map(link => renderLink(link))}
      </div>

      {/* Discount Campaign Banner */}
      <CampaignBanner onUpgrade={() => openUpgrade()} />

      {/* Usage Bars — only for free plan */}
      {isFree && (
        <Card className="mb-4 shadow-card">
          <CardContent className="p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">مصرف طرح رایگان</span>
              <button onClick={() => openUpgrade('customers')} className="text-[10px] text-primary font-medium">
                ارتقا →
              </button>
            </div>
            <UsageBar label="مشتریان" used={custCount} limit={DEFAULT_FREE_QUOTAS.customers} />
            <UsageBar label="حواله امروز" used={todayTransferCount} limit={DEFAULT_FREE_QUOTAS.daily_transfers} />
            <UsageBar label="تراکنش ماه" used={monthTxCount} limit={DEFAULT_FREE_QUOTAS.monthly_transactions} />
          </CardContent>
        </Card>
      )}

      {/* Quota Card — compact, for free plan */}
      {isFree && quota && (
        <Card className="mb-4 overflow-hidden shadow-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">سهمیه عملیات</span>
              <button onClick={() => openUpgrade()} className="text-[10px] text-primary font-medium">
                ارتقا →
              </button>
            </div>
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full transition-all"
                style={{ width: `${quota.limit > 0 ? Math.min(100, (quota.used / quota.limit) * 100) : 0}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-1">{formatNumber(quota.remaining)} عملیات باقی‌مانده</p>
          </CardContent>
        </Card>
      )}

      {/* Secondary Links — collapsible */}
      <button
        onClick={() => setMoreOpen(true)}
        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-muted/50 hover:bg-muted text-sm text-muted-foreground font-medium transition-colors mb-4"
      >
        <MoreHorizontal className="w-4 h-4" />
        بخش‌های بیشتر
      </button>

      {/* Free plan — branding badge note */}
      {isFree && (
        <div className="mb-2 rounded-xl border border-warning/30 bg-warning/5 p-3 flex items-center gap-2">
          <span className="text-xs text-muted-foreground flex-1">
            🏷️ نسخه رایگان — با ارتقا به نسخه پولی، برند سازنده از پایین صفحه حذف می‌شود
          </span>
          <button onClick={() => openUpgrade()} className="text-[10px] text-primary font-medium whitespace-nowrap">
            ارتقا →
          </button>
        </div>
      )}

      {/* Recent Transactions */}
      <h3 className="text-sm font-bold text-foreground mb-2.5 mt-4">تراکنش‌های اخیر</h3>
      <Card className="shadow-card">
        <CardContent className="p-2">
          {txLoading ? (
            <LoadingState />
          ) : (txs || []).length === 0 ? (
            <EmptyState icon={FileText} title="تراکنشی ثبت نشده" description="اولین عملیات خود را انجام دهید" />
          ) : (
            (txs || []).slice(0, 8).map(tx => (
              <TransactionRow key={tx.id} tx={tx} labels={TX_TYPE_LABELS} onClick={() => navigate(`/receipt?type=tx&id=${tx.id}`)} />
            ))
          )}
        </CardContent>
      </Card>

      {/* More Menu Modal */}
      {moreOpen && (
        <div className="fixed inset-0 z-50 bg-black/50" onClick={() => setMoreOpen(false)}>
          <div className="absolute bottom-0 inset-x-0 bg-background rounded-t-2xl p-4 max-h-[70vh] overflow-y-auto scrollbar-thin" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-foreground">همه بخش‌ها</h3>
              <button onClick={() => setMoreOpen(false)} className="p-1.5 rounded-lg hover:bg-muted">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2.5">
              {secondaryLinks.map(link => renderLink(link, true))}
            </div>
          </div>
        </div>
      )}

    </FeatureGate>
  );
}