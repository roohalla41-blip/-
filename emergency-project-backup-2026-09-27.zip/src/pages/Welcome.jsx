import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Shield, ArrowLeft, Store, UserCircle } from 'lucide-react';
import ContactInfo from '@/components/sarraaf/ContactInfo';

export default function Welcome() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 flex flex-col items-center justify-between px-5 py-8">
      {/* Top spacer */}
      <div className="flex-1" />

      {/* Hero Section */}
      <div className="w-full max-w-sm text-center">
        <h1 className="text-3xl font-extrabold text-foreground tracking-tight mb-2">
          حساب صراف
        </h1>
        <p className="text-sm text-muted-foreground leading-relaxed mb-3 max-w-[260px] mx-auto">
          سامانه جامع مدیریت صرافی، تبدیل ارز و حسابداری مالی
        </p>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-success/10 text-success text-xs font-medium mb-8">
          <Shield className="w-3.5 h-3.5" />
          محیط امن مالی
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5">
          <Link to="/login" className="block">
            <Button className="w-full h-12 text-base font-semibold" size="lg">
              <ArrowLeft className="w-5 h-5" />
              ورود به حساب
            </Button>
          </Link>
          <div className="grid grid-cols-2 gap-2">
            <Link to="/register?type=sarraaf" className="block">
              <Button variant="outline" className="w-full h-11 text-sm font-medium" size="lg">
                <Store className="w-4 h-4 ml-1" />
                ثبت‌نام صراف
              </Button>
            </Link>
            <Link to="/register?type=customer" className="block">
              <Button variant="outline" className="w-full h-11 text-sm font-medium" size="lg">
                <UserCircle className="w-4 h-4 ml-1" />
                ثبت‌نام مشتری
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="w-full max-w-sm mt-8">
        <ContactInfo />
        <p className="text-[11px] text-muted-foreground/50 text-center mt-6">
          © 2026 حساب صراف — تمامی حقوق محفوظ است
        </p>
      </div>
    </div>
  );
}