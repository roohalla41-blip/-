import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { callSupabase } from '@/lib/supabaseApi';
import { login as localLogin } from '@/lib/localAuth';
import { cacheCredentialsForOffline, offlineLogin, findCachedUser } from '@/lib/credentialCache';
import { isLocalTestMode } from '@/lib/localTestMode';
import { initiateGoogleLogin, handleGoogleCallback } from '@/lib/googleAuth';
import { applyCreatorRole } from '@/lib/creatorAuth';
import { recordLoginAttempt, isAccountLocked, getLockoutRemaining, getRemainingAttempts } from '@/lib/loginSecurity';
import { logAudit, AUDIT_ACTIONS } from '@/lib/auditLogger';
import { useAuth } from '@/lib/AuthContext';
import GoogleIcon from '@/components/GoogleIcon';
import BrandMark from '@/components/BrandMark';
import ConnectionStatus from '@/components/ConnectionStatus';
import { ArrowLeft, Phone, Lock, User, Store, UserCircle, WifiOff, Loader2, Shield } from 'lucide-react';

const ERR_MAP = {
  user_not_found: 'نام کاربری یا موبایل یافت نشد',
  wrong_password: 'رمز عبور اشتباه است',
  user_inactive: 'حساب کاربری غیرفعال است',
  missing_fields: 'نام کاربری و رمز عبور را وارد کنید',
  mobile_exists: 'این شماره موبایل قبلاً ثبت شده است',
  username_exists: 'این نام کاربری قبلاً ثبت شده است',
  server_error: 'خطا در ارتباط با سرور',
};

function mapServerUser(dbUser, exchange) {
  return applyCreatorRole({
    id: String(dbUser.id || ''),
    full_name: dbUser.full_name || dbUser.name || '',
    name: dbUser.full_name || dbUser.name || '',
    mobile: dbUser.mobile || '',
    username: dbUser.username || '',
    email: dbUser.email || '',
    role: dbUser.role || 'exchange',
    account_type: dbUser.account_type || (dbUser.role === 'creator' ? 'admin' : dbUser.role),
    status: dbUser.status || 'active',
    exchange_code: exchange?.exchange_code || dbUser.exchange_code || '',
    exchange_name: exchange?.exchange_name || dbUser.exchange_name || '',
  });
}

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, isAuthenticated } = useAuth();
  const offlineAdminBlocked = location.state?.reason === 'offline_admin';
  const [tab, setTab] = useState('sarraaf');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [googleLoading, setGoogleLoading] = useState(false);
  // hasInternet = real device connectivity (navigator.onLine).
  // NOT affected by local test mode — device can have internet
  // even when we're storing data locally instead of in Supabase.
  const [hasInternet, setHasInternet] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  // Redirect already-authenticated users away from login
  useEffect(() => {
    if (isAuthenticated && user) {
      const role = user.role;
      if (role === 'creator') window.location.href = '/builder';
      else if (role === 'customer') window.location.href = '/customer';
      else window.location.href = '/dashboard';
    }
  }, [isAuthenticated, user]);

  useEffect(() => {
    const handleOnline = () => setHasInternet(true);
    const handleOffline = () => setHasInternet(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // ── Google OAuth callback handler (Supabase) ──
  // Supabase Auth redirects back with ?google_cb=1 — we exchange the
  // session for an HMAC token via the backend, then navigate.
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('google_cb') !== '1') return;
    setGoogleLoading(true);
    handleGoogleCallback().then(() => {
      const returnTo = urlParams.get('return_to') || '/dashboard';
      window.location.href = returnTo;
    }).catch(() => {
      setGoogleLoading(false);
    });
  }, []);

  const navigateByRole = (role) => {
    // Hard redirect so AuthContext re-initializes and picks up the new session
    if (role === 'creator') window.location.href = '/builder';
    else if (role === 'customer') window.location.href = '/customer';
    else window.location.href = '/dashboard';
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      // ── بررسی قفل شدن حساب ──
      if (isAccountLocked(identifier)) {
        const remaining = getLockoutRemaining(identifier);
        const mins = Math.ceil(remaining / 60);
        throw new Error(`حساب به دلیل تلاش‌های ناموفق متعدد قفل شده است. ${mins} دقیقه دیگر تلاش کنید.`);
      }

      const online = hasInternet && !isLocalTestMode();

      // ── مرحله ۱: ورود از طریق سرور (اولویت وقتی آنلاین هستیم) ──
      if (online) {
        let serverResult = null;
        let serverError = null;
        try {
          const res = await callSupabase('login', { identifier, password });
          if (res?.success) {
            serverResult = res;
          } else {
            serverError = res?.error || 'server_error';
          }
        } catch {
          serverError = 'network_error';
        }

        if (serverResult) {
          const mappedUser = mapServerUser(serverResult.user, serverResult.exchange);
          // اطلاعات سازنده هرگز در localStorage ذخیره نمی‌شود
          if (mappedUser.role !== 'creator') {
            await cacheCredentialsForOffline(identifier, password, mappedUser);
            localStorage.setItem('auth_user', JSON.stringify(mappedUser));
          }
          localStorage.setItem('auth_token', serverResult.token);
          recordLoginAttempt(identifier, true);
          logAudit({ userId: mappedUser.id, userName: mappedUser.full_name, userRole: mappedUser.role, action: AUDIT_ACTIONS.LOGIN, description: 'ورود سرور موفق', status: 'success' });
          navigateByRole(mappedUser.role);
          return;
        }

        // اگر سرور خطای قطعی داد (کاربر وجود دارد ولی رمز اشتباه، یا کاربر یافت نشد)،
        // به Local Auth برنمی‌گردیم — این خطای واقعی Login است.
        if (serverError === 'wrong_password' || serverError === 'user_not_found' || serverError === 'user_inactive' || serverError === 'too_many_attempts') {
          recordLoginAttempt(identifier, false);
          logAudit({ userName: identifier, action: AUDIT_ACTIONS.LOGIN_FAILED, description: `ورود ناموفق (${serverError})`, status: 'failed' });
          throw new Error(ERR_MAP[serverError] || 'خطا در ورود');
        }
        // در غیر این صورت (خطای شبکه/سرور) — به fallback آفلاین ادامه می‌دهیم
        // سازنده نمی‌تواند آفلاین وارد شود چون اطلاعات او در localStorage ذخیره نمی‌شود
      }

      // ── مرحله ۲: اعتبارنامه‌های کش‌شده (offline cache) ──
      const offRes = await offlineLogin(identifier, password);
      if (offRes.success) {
        const finalUser = applyCreatorRole(offRes.user);
        // سازنده نمی‌تواند از طریق کش آفلاین وارد شود
        if (finalUser.role === 'creator') {
          throw new Error('حساب سازنده نیازمند اتصال به سرور است. لطفاً اتصال اینترنت را بررسی کنید.');
        }
        localStorage.setItem('auth_user', JSON.stringify(finalUser));
        localStorage.setItem('auth_token', `local_token_${Date.now()}`);
        recordLoginAttempt(identifier, true);
        logAudit({ userId: finalUser.id, userName: finalUser.full_name, userRole: finalUser.role, action: AUDIT_ACTIONS.LOGIN, description: 'ورود آفلاین موفق', status: 'success' });
        navigateByRole(finalUser.role);
        return;
      }

      // ── مرحله ۳: کاربران محلی (localAuth) — فقط در حالت آفلاین ──
      if (!online) {
        const locRes = localLogin(identifier, password);
        if (locRes.success) {
          const finalUser = applyCreatorRole(locRes.user);
          // سازنده نمی‌تواند از طریق کاربران محلی وارد شود
          if (finalUser.role === 'creator') {
            throw new Error('حساب سازنده نیازمند اتصال به سرور است. لطفاً اتصال اینترنت را بررسی کنید.');
          }
          await cacheCredentialsForOffline(identifier, password, finalUser);
          recordLoginAttempt(identifier, true);
          logAudit({ userId: finalUser.id, userName: finalUser.full_name, userRole: finalUser.role, action: AUDIT_ACTIONS.LOGIN, description: 'ورود محلی موفق', status: 'success' });
          navigateByRole(finalUser.role);
          return;
        }
      }

      // ── مرحله ۴: خطا بر اساس وضعیت ──
      recordLoginAttempt(identifier, false);
      logAudit({ userName: identifier, action: AUDIT_ACTIONS.LOGIN_FAILED, description: 'ورود ناموفق', status: 'failed' });
      const remaining = getRemainingAttempts(identifier);
      if (findCachedUser(identifier)) {
        throw new Error(`رمز عبور اشتباه است. ${remaining} تلاش باقی مانده.`);
      }
      if (!hasInternet) {
        throw new Error('برای اولین ورود، اتصال به اینترنت لازم است.');
      }
      throw new Error(`نام کاربری یا رمز عبور اشتباه است. ${remaining} تلاش باقی مانده.`);
    } catch (err) {
      setError(err.message || 'خطا در ورود');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* نشانگر وضعیت اتصال */}
        <div className="flex justify-center mb-4">
          <ConnectionStatus compact />
        </div>

        {/* هشدار آفلاین */}
        {!hasInternet && (
          <div className="flex items-center gap-2 mb-4 p-3 rounded-lg bg-warning/10 text-warning text-xs text-center justify-center">
            <WifiOff className="w-4 h-4" />
            <span>حالت آفلاین — فقط کاربرانی که قبلاً روی این دستگاه وارد شده‌اند می‌توانند وارد شوند.</span>
          </div>
        )}

        {/* هشدار: پنل سازنده فقط آنلاین */}
        {offlineAdminBlocked && (
          <div className="flex items-center gap-2 mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-xs text-center justify-center">
            <Shield className="w-4 h-4" />
            <span>ورود به پنل سازنده فقط در حالت آنلاین ممکن است. لطفاً اتصال اینترنت را برقرار کنید.</span>
          </div>
        )}

        <div className="text-center mb-6">
          <div className="flex justify-center mb-3">
            <BrandMark size="md" />
          </div>
          <h1 className="text-xl font-bold text-foreground">ورود به حساب صراف</h1>
          <p className="text-xs text-muted-foreground mt-1">سامانه تخصصی مدیریت صرافی</p>
        </div>

        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="sarraaf">
              <Store className="w-4 h-4 ml-1" />
              ورود صراف
            </TabsTrigger>
            <TabsTrigger value="customer">
              <UserCircle className="w-4 h-4 ml-1" />
              ورود مشتری
            </TabsTrigger>
          </TabsList>

          <TabsContent value="sarraaf" className="mt-4">
            <form onSubmit={handleLogin} className="space-y-3">
              <div>
                <Label>نام کاربری یا موبایل</Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={identifier}
                    onChange={e => setIdentifier(e.target.value)}
                    placeholder="نام کاربری / موبایل / admin"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>رمز عبور</Label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="رمز عبور"
                    className="pr-9"
                  />
                  </div>
                  </div>
                  {error && <p className="text-sm text-destructive text-center">{error}</p>}
                  <Button type="submit" className="w-full" disabled={loading}>
                  <ArrowLeft className="w-4 h-4" />
                  {loading ? 'در حال ورود...' : 'ورود'}
                  </Button>
                  <Link to="/register?type=sarraaf" className="block text-center text-xs text-muted-foreground hover:text-foreground">
                  حساب ندارید؟ ثبت‌نام صراف
                  </Link>
              <Link to="/forgot-password" className="block text-center text-xs text-muted-foreground hover:text-foreground">
                فراموشی رمز عبور
              </Link>
            </form>
          </TabsContent>

          <TabsContent value="customer" className="mt-4">
            <form onSubmit={handleLogin} className="space-y-3">
              <div>
                <Label>نام کاربری یا موبایل</Label>
                <div className="relative">
                  <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={identifier}
                    onChange={e => setIdentifier(e.target.value)}
                    placeholder="نام کاربری / موبایل / ایمیل"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>رمز عبور</Label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="رمز عبور"
                    className="pr-9"
                  />
                  </div>
                  </div>
                  {error && <p className="text-sm text-destructive text-center">{error}</p>}
                  <Button type="submit" className="w-full" disabled={loading}>
                  <ArrowLeft className="w-4 h-4" />
                  {loading ? 'در حال ورود...' : 'ورود'}
                  </Button>
                  <Link to="/register?type=customer" className="block text-center text-xs text-muted-foreground hover:text-foreground">
                  حساب ندارید؟ ثبت‌نام مشتری
                  </Link>
              <Link to="/forgot-password" className="block text-center text-xs text-muted-foreground hover:text-foreground">
                فراموشی رمز عبور
              </Link>
            </form>
          </TabsContent>
        </Tabs>

        {/* Google Login — فقط برای صراف */}
        {tab === 'sarraaf' && (
          googleLoading ? (
            <div className="mt-6 flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="w-4 h-4 animate-spin" />
              در حال ورود با گوگل...
            </div>
          ) : (
            <div className="mt-6 space-y-3">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-background px-2 text-muted-foreground">یا</span>
                </div>
              </div>
              <Button
                type="button"
                variant="outline"
                className="w-full h-11"
                onClick={() => initiateGoogleLogin('/dashboard')}
              >
                <GoogleIcon className="w-5 h-5" />
                ورود با گوگل
              </Button>
            </div>
          )
        )}

        <div className="mt-4 text-center">
          <Link to="/" className="text-xs text-muted-foreground hover:text-foreground">
            بازگشت به صفحه اصلی
          </Link>
        </div>
      </div>
    </div>
  );
}