import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { callSupabase } from '@/lib/supabaseApi';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cacheCredentialsForOffline } from '@/lib/credentialCache';
import { initiateGoogleLogin } from '@/lib/googleAuth';
import { processReferral } from '@/lib/referralSystem';
import GoogleIcon from '@/components/GoogleIcon';
import BrandMark from '@/components/BrandMark';
import { ArrowLeft, User, Lock, Mail, Store, Phone, MapPin, UserCircle, ShieldCheck, Send, Loader2, WifiOff, Gift } from 'lucide-react';

const ERRORS = {
  missing_fields: 'لطفاً تمام فیلدهای ضروری را پر کنید',
  mobile_exists: 'این شماره موبایل قبلاً ثبت‌نام شده است. لطفاً با نام کاربری و رمز عبور خود وارد شوید.',
  username_exists: 'این نام کاربری قبلاً استفاده شده است. لطفاً نام کاربری دیگری انتخاب کنید.',
  server_error: 'خطای سرور. لطفاً بعداً تلاش کنید.',
  no_internet: 'برای ثبت‌نام اولیه، اینترنت لازم است. لطفاً اینترنت خود را وصل کنید و دوباره تلاش کنید.',
};

export default function Register() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const [searchParams] = useSearchParams();
  const initialTab = searchParams.get('type') === 'customer' ? 'customer' : 'sarraaf';
  const [tab, setTab] = useState(initialTab);

  // Redirect already-authenticated users away from register
  useEffect(() => {
    if (isAuthenticated && user) {
      const role = user.role;
      if (role === 'creator' || role === 'admin') window.location.href = '/builder';
      else if (role === 'customer') window.location.href = '/customer';
      else window.location.href = '/dashboard';
    }
  }, [isAuthenticated, user]);

  // Common state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showEmail, setShowEmail] = useState(false);
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sarraaf fields
  const [exExchangeName, setExExchangeName] = useState('');
  const [exFullName, setExFullName] = useState('');
  const [exMobile, setExMobile] = useState('');
  const [exUsername, setExUsername] = useState('');
  const [exEmail, setExEmail] = useState('');
  const [exPassword, setExPassword] = useState('');
  const [exConfirmPassword, setExConfirmPassword] = useState('');
  const [exCountry, setExCountry] = useState('');
  const [exCity, setExCity] = useState('');
  const [exReferralCode, setExReferralCode] = useState('');
  const [exEmailCode, setExEmailCode] = useState('');
  const [exEmailVerified, setExEmailVerified] = useState(false);
  const [exCodeSent, setExCodeSent] = useState(false);
  const [exCodeSending, setExCodeSending] = useState(false);
  const [exCodeError, setExCodeError] = useState('');
  const [exCodeVerifying, setExCodeVerifying] = useState(false);

  // Customer fields
  const [cuFullName, setCuFullName] = useState('');
  const [cuMobile, setCuMobile] = useState('');
  const [cuUsername, setCuUsername] = useState('');
  const [cuEmail, setCUEmail] = useState('');
  const [cuPassword, setCuPassword] = useState('');
  const [cuConfirmPassword, setCuConfirmPassword] = useState('');
  const [cuReferralCode, setCuReferralCode] = useState('');

  const handleSendExCode = async () => {
    setExCodeError('');
    const email = (exEmail || '').trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setExCodeError('ابتدا یک ایمیل معتبر وارد کنید');
      return;
    }
    if (!exPassword || exPassword.length < 8) {
      setExCodeError('ابتدا رمز عبور را وارد کنید (حداقل ۸ کاراکتر)');
      return;
    }
    setExCodeSending(true);
    try {
      if (exCodeSent) {
        const res = await callSupabase('auth_resend', { email });
        if (!res?.success) throw new Error(res?.error || '');
      } else {
        const res = await callSupabase('auth_signup', { email, password: exPassword });
        if (!res?.success) throw new Error(res?.error || '');
        setExCodeSent(true);
        setExEmailVerified(false);
      }
    } catch (err) {
      const msg = (err?.message || '').toLowerCase();
      if (msg.includes('email_exists')) {
        setExCodeError('این ایمیل قبلاً ثبت شده است. لطفاً وارد شوید یا ایمیل دیگری استفاده کنید.');
      } else if (msg.includes('rate_limit')) {
        setExCodeError(err?.message?.includes('۴ ساعت') ? 'برای ارسال مجدد کد، ۴ ساعت صبر کنید.' : 'لطفاً کمی صبر کنید و دوباره تلاش کنید.');
      } else {
        const detail = err?.message || err?.data?.detail || err?.data?.message || '';
        setExCodeError(`ارسال کد ناموفق بود${detail ? ': ' + detail : ''}. لطفاً دوباره تلاش کنید.`);
      }
    } finally {
      setExCodeSending(false);
    }
  };

  const handleVerifyExCode = async () => {
    setExCodeError('');
    const code = (exEmailCode || '').trim();
    const email = (exEmail || '').trim();
    if (!code || code.length !== 6) {
      setExCodeError('کد تأیید ۶ رقمی را وارد کنید');
      return;
    }
    setExCodeVerifying(true);
    try {
      const res = await callSupabase('auth_verifyOtp', { email, token: code });
      if (!res?.success) throw new Error(res?.error || '');
      // Mark as verified — email confirmed via Supabase Auth
      setExEmailVerified(true);
      setExCodeError('');
    } catch (err) {
      const msg = (err?.message || '').toLowerCase();
      if (msg.includes('no_code_sent')) {
        setExCodeError('ابتدا کد را ارسال کنید');
      } else if (msg.includes('code_expired')) {
        setExCodeError('کد منقضی شده است. دوباره ارسال کنید.');
      } else if (msg.includes('too_many_attempts')) {
        setExCodeError('تلاش‌های زیادی انجام شد. دوباره کد ارسال کنید.');
      } else {
        const detail = err?.message || '';
        setExCodeError(`کد تأیید اشتباه است${detail ? ': ' + detail : ''}`);
      }
    } finally {
      setExCodeVerifying(false);
    }
  };

  const handleSarraafRegister = async (e) => {
    e.preventDefault();
    setError('');
    if (!exExchangeName || !exFullName || !exMobile || !exUsername || !exPassword || !exEmail) {
      setError('لطفاً تمام فیلدهای ضروری را پر کنید');
      return;
    }
    if (exPassword.length < 8) { setError('رمز عبور باید حداقل ۸ کاراکتر باشد'); return; }
    if (exPassword !== exConfirmPassword) { setError('تکرار رمز مطابقت ندارد'); return; }
    if (exMobile.length < 10) { setError('شماره موبایل معتبر وارد کنید'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(exEmail)) { setError('ایمیل معتبر وارد کنید'); return; }
    if (!exEmailVerified) { setError('لطفاً ایمیل خود را با کد تأیید کنید'); return; }

    // ── الزامی بودن اینترنت برای ثبت‌نام اولیه ──
    if (typeof navigator === 'undefined' || !navigator.onLine) {
      setError(ERRORS.no_internet);
      return;
    }

    setLoading(true);
    try {
      const res = await callSupabase('registerExchange', {
        exchange_name: exExchangeName,
        full_name: exFullName,
        mobile: exMobile,
        username: exUsername,
        password: exPassword,
        email: exEmail,
        country: exCountry,
        city: exCity,
      });
      if (!res?.success) {
        throw new Error(ERRORS[res?.error] || res?.error || 'خطا در ثبت‌نام');
      }
      // ── ثبت موفق در Supabase ──
      // اطلاعات کاربر و صرافی برگشتی از سرور
      const serverUser = res.user;
      const serverExchange = res.exchange;
      const mappedUser = {
        id: String(serverUser.id || ''),
        full_name: serverUser.full_name || '',
        name: serverUser.full_name || '',
        mobile: serverUser.mobile || '',
        username: serverUser.username || '',
        email: serverUser.email || '',
        role: serverUser.role || 'exchange',
        account_type: serverUser.role === 'creator' ? 'admin' : serverUser.role,
        status: serverUser.status || 'active',
        exchange_code: serverExchange?.exchange_code || '',
        exchange_name: serverExchange?.exchange_name || '',
      };
      // ── کش اعتبارنامه برای ورود آفلاین (فقط بعد از ثبت موفق در سرور) ──
      await cacheCredentialsForOffline(exMobile, exPassword, mappedUser);
      // ذخیره نشست برای AuthContext
      localStorage.setItem('auth_user', JSON.stringify(mappedUser));
      localStorage.setItem('auth_token', res.token);
      // ── پردازش کد دعوت (در صورت وجود) ──
      if (exReferralCode) {
        try {
          await processReferral(exReferralCode, String(serverUser.id || ''), exFullName, 'sarraaf');
        } catch {
          // ignore — referral processing is non-blocking
        }
      }
      // ── ایجاد پروفایل صراف در دیتابیس Base44 (برای نمایش در پنل سازنده) ──
      try {
        const { offlineDB } = await import('@/lib/offlineQueue');
        const profileCode = serverExchange?.exchange_code || `EX-${Date.now()}`;
        await offlineDB.SarraafProfile.create({
          code: profileCode,
          user_id: String(serverUser.id || ''),
          email: exEmail,
          exchange_name: exExchangeName,
          name: exFullName,
          phone: exMobile,
          plan: 'free',
          quota_limit: 100,
          quota_used: 0,
          payment_status: 'none',
          status: 'active',
          last_login: new Date().toISOString(),
        });
      } catch {
        // ignore — profile creation is non-blocking
      }
      // Hard redirect so AuthContext re-initializes and picks up the new session
      window.location.href = '/dashboard';
    } catch (err) {
      const msg = (err?.message || '').toLowerCase();
      if (msg.includes('network') || msg.includes('fetch') || msg.includes('failed to fetch')) {
        setError(ERRORS.no_internet);
      } else {
        setError(err.message || 'خطا در ثبت‌نام');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCustomerRegister = async (e) => {
    e.preventDefault();
    setError('');
    if (!cuFullName || !cuMobile || !cuUsername || !cuPassword) {
      setError('لطفاً تمام فیلدهای ضروری را پر کنید');
      return;
    }
    if (cuPassword.length < 8) { setError('رمز عبور باید حداقل ۸ کاراکتر باشد'); return; }
    if (cuPassword !== cuConfirmPassword) { setError('تکرار رمز مطابقت ندارد'); return; }
    if (cuMobile.length < 10) { setError('شماره موبایل معتبر وارد کنید'); return; }

    // ── الزامی بودن اینترنت برای ثبت‌نام اولیه ──
    if (typeof navigator === 'undefined' || !navigator.onLine) {
      setError(ERRORS.no_internet);
      return;
    }

    setLoading(true);
    try {
      const res = await callSupabase('registerCustomer', {
        full_name: cuFullName,
        mobile: cuMobile,
        username: cuUsername,
        password: cuPassword,
        email: showEmail ? cuEmail : '',
      });
      if (!res?.success) {
        throw new Error(ERRORS[res?.error] || res?.error || 'خطا در ثبت‌نام');
      }
      // ── ثبت موفق در Supabase ──
      const serverUser = res.user;
      const mappedUser = {
        id: String(serverUser.id || ''),
        full_name: serverUser.full_name || '',
        name: serverUser.full_name || '',
        mobile: serverUser.mobile || '',
        username: serverUser.username || '',
        email: serverUser.email || '',
        role: serverUser.role || 'customer',
        account_type: serverUser.role === 'creator' ? 'admin' : serverUser.role,
        status: serverUser.status || 'active',
      };
      // ── کش اعتبارنامه برای ورود آفلاین (فقط بعد از ثبت موفق در سرور) ──
      await cacheCredentialsForOffline(cuMobile, cuPassword, mappedUser);
      localStorage.setItem('auth_user', JSON.stringify(mappedUser));
      localStorage.setItem('auth_token', res.token);
      // ── پردازش کد دعوت (در صورت وجود) ──
      if (cuReferralCode) {
        try {
          await processReferral(cuReferralCode, String(serverUser.id || ''), cuFullName, 'customer');
        } catch {
          // ignore — referral processing is non-blocking
        }
      }
      // ── ایجاد رکورد مشتری در دیتابیس Base44 (برای نمایش در پنل سازنده) ──
      try {
        const { offlineDB } = await import('@/lib/offlineQueue');
        await offlineDB.Customer.create({
          name: cuFullName,
          phone: cuMobile,
          code: `CUS-${Date.now().toString().slice(-6)}`,
          status: 'active',
          customer_type: 'permanent',
          notes: `ثبت‌نام آنلاین — ${new Date().toLocaleDateString('fa-IR')}`,
        });
      } catch {
        // ignore — customer record creation is non-blocking
      }
      window.location.href = '/customer';
    } catch (err) {
      const msg = (err?.message || '').toLowerCase();
      if (msg.includes('network') || msg.includes('fetch') || msg.includes('failed to fetch')) {
        setError(ERRORS.no_internet);
      } else {
        setError(err.message || 'خطا در ثبت‌نام');
      }
    } finally {
      setLoading(false);
    }
  };

  const renderEmailToggle = (email, setEmail) => (
    <div>
      {!showEmail ? (
        <Button
          type="button"
          variant="outline"
          className="w-full text-sm"
          onClick={() => setShowEmail(true)}
        >
          <Mail className="w-4 h-4 ml-1" />
          ثبت‌نام با ایمیل (اختیاری)
        </Button>
      ) : (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>ایمیل (اختیاری)</Label>
            <button
              type="button"
              className="text-xs text-muted-foreground hover:text-foreground"
              onClick={() => { setShowEmail(false); setEmail(''); }}
            >
              حذف ایمیل
            </button>
          </div>
          <div className="relative">
            <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="email@example.com"
              className="pr-9"
            />
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="flex justify-center mb-3">
            <BrandMark size="md" />
          </div>
          <h1 className="text-xl font-bold text-foreground">ثبت‌نام در حساب صراف</h1>
          <p className="text-xs text-muted-foreground mt-1">سامانه تخصصی مدیریت صرافی</p>
          <p className="text-xs text-muted-foreground mt-2 leading-relaxed">
            📌 این صفحه فقط برای ثبت‌نام اولیه است و همیشه از شما خواسته نمی‌شود. اگر قبلاً حساب دارید، به صفحه ورود بروید.
          </p>
        </div>

        {!isOnline && (
          <div className="mb-4 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-center">
            <WifiOff className="w-5 h-5 text-destructive mx-auto mb-1" />
            <p className="text-xs text-destructive font-medium">
              برای ثبت‌نام اولیه، اینترنت لازم است. لطفاً اینترنت خود را وصل کنید و دوباره تلاش کنید.
            </p>
          </div>
        )}

        <Tabs value={tab} onValueChange={(v) => { setTab(v); setError(''); setShowEmail(false); }} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="sarraaf">
              <Store className="w-4 h-4 ml-1" />
              ثبت‌نام صراف
            </TabsTrigger>
            <TabsTrigger value="customer">
              <UserCircle className="w-4 h-4 ml-1" />
              ثبت‌نام مشتری
            </TabsTrigger>
          </TabsList>

          {/* Sarraaf Registration */}
          <TabsContent value="sarraaf" className="mt-4">
            <form onSubmit={handleSarraafRegister} className="space-y-3">
              <div>
                <Label>نام صرافی <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <Store className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={exExchangeName}
                    onChange={e => setExExchangeName(e.target.value)}
                    placeholder="نام صرافی"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>نام و نام خانوادگی مسئول صرافی <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={exFullName}
                    onChange={e => setExFullName(e.target.value)}
                    placeholder="نام و نام خانوادگی"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>شماره موبایل <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={exMobile}
                    onChange={e => setExMobile(e.target.value)}
                    placeholder="07XXXXXXXX"
                    className="pr-9"
                    inputMode="numeric"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>نام کاربری <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={exUsername}
                    onChange={e => setExUsername(e.target.value)}
                    placeholder="نام کاربری (یکتا)"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>رمز عبور <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="password"
                    value={exPassword}
                    onChange={e => setExPassword(e.target.value)}
                    placeholder="حداقل ۸ کاراکتر"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>تکرار رمز عبور <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="password"
                    value={exConfirmPassword}
                    onChange={e => setExConfirmPassword(e.target.value)}
                    placeholder="تکرار رمز"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>ایمیل <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="email"
                    value={exEmail}
                    onChange={(e) => { setExEmail(e.target.value); setExEmailVerified(false); setExCodeSent(false); }}
                    placeholder="email@example.com"
                    className="pr-9"
                    required
                  />
                </div>
                {!exEmailVerified && (
                  <div className="flex gap-2">
                    <Input
                      value={exEmailCode}
                      onChange={(e) => setExEmailCode(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          if (!exEmailVerified && exCodeSent) handleVerifyExCode();
                        }
                      }}
                      placeholder="کد تأیید ۶ رقمی"
                      className="flex-1 text-center tracking-widest"
                      inputMode="numeric"
                      maxLength={6}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleSendExCode}
                      disabled={exCodeSending}
                    >
                      {exCodeSending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : exCodeSent ? 'ارسال مجدد' : (
                        <><Send className="w-3.5 h-3.5 ml-1" /> ارسال کد</>
                      )}
                    </Button>
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      onClick={handleVerifyExCode}
                      disabled={exCodeVerifying || !exCodeSent}
                    >
                      {exCodeVerifying ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <><ShieldCheck className="w-3.5 h-3.5" /> تأیید</>}
                    </Button>
                  </div>
                )}
                {exEmailVerified && (
                  <p className="text-xs text-green-600 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> ایمیل تأیید شد
                  </p>
                )}
                {exCodeError && <p className="text-xs text-destructive">{exCodeError}</p>}
                {exCodeSent && !exEmailVerified && (
                  <p className="text-[10px] text-muted-foreground">
                    کد ۶ رقمی به ایمیل شما ارسال شد. اگر دریافت نکردید، پوشه Spam/Bulk را چک کنید.
                  </p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>کشور</Label>
                  <div className="relative">
                    <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      value={exCountry}
                      onChange={e => setExCountry(e.target.value)}
                      placeholder="کشور"
                      className="pr-9"
                    />
                  </div>
                </div>
                <div>
                  <Label>شهر</Label>
                  <Input
                    value={exCity}
                    onChange={e => setExCity(e.target.value)}
                    placeholder="شهر"
                  />
                </div>
              </div>
              <div>
                <Label>کد دعوت (اختیاری)</Label>
                <div className="relative">
                  <Gift className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={exReferralCode}
                    onChange={e => setExReferralCode(e.target.value)}
                    placeholder="کد دعوت صراف/دوست"
                    className="pr-9 uppercase"
                  />
                </div>
              </div>
              {error && <p className="text-sm text-destructive text-center">{error}</p>}
              <Button type="submit" className="w-full" disabled={loading}>
                <ArrowLeft className="w-4 h-4" />
                {loading ? 'در حال ثبت...' : 'ثبت‌نام صراف'}
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                کد صرافی توسط سیستم به‌صورت خودکار ایجاد می‌شود.
              </p>
              <Link to="/login" className="block text-center text-xs text-muted-foreground hover:text-foreground">
                حساب دارم — ورود
              </Link>
            </form>
          </TabsContent>

          {/* Customer Registration */}
          <TabsContent value="customer" className="mt-4">
            <form onSubmit={handleCustomerRegister} className="space-y-3">
              <div>
                <Label>نام و نام خانوادگی <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={cuFullName}
                    onChange={e => setCuFullName(e.target.value)}
                    placeholder="نام و نام خانوادگی"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>شماره موبایل <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={cuMobile}
                    onChange={e => setCuMobile(e.target.value)}
                    placeholder="07XXXXXXXX"
                    className="pr-9"
                    inputMode="numeric"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>نام کاربری <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={cuUsername}
                    onChange={e => setCuUsername(e.target.value)}
                    placeholder="نام کاربری (یکتا)"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              {renderEmailToggle(cuEmail, setCUEmail)}
              <div>
                <Label>رمز عبور <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="password"
                    value={cuPassword}
                    onChange={e => setCuPassword(e.target.value)}
                    placeholder="حداقل ۸ کاراکتر"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>تکرار رمز عبور <span className="text-destructive">*</span></Label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="password"
                    value={cuConfirmPassword}
                    onChange={e => setCuConfirmPassword(e.target.value)}
                    placeholder="تکرار رمز"
                    className="pr-9"
                    required
                  />
                </div>
              </div>
              <div>
                <Label>کد دعوت (اختیاری)</Label>
                <div className="relative">
                  <Gift className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={cuReferralCode}
                    onChange={e => setCuReferralCode(e.target.value)}
                    placeholder="کد دعوت صراف/دوست"
                    className="pr-9 uppercase"
                  />
                </div>
              </div>
              {error && <p className="text-sm text-destructive text-center">{error}</p>}
              <Button type="submit" className="w-full" disabled={loading}>
                <ArrowLeft className="w-4 h-4" />
                {loading ? 'در حال ثبت...' : 'ثبت‌نام مشتری'}
              </Button>
              <Link to="/login" className="block text-center text-xs text-muted-foreground hover:text-foreground">
                حساب دارم — ورود
              </Link>
            </form>
          </TabsContent>
        </Tabs>

        {/* Google Registration — فقط برای صراف */}
        {tab === 'sarraaf' && (
          <div className="mt-6 space-y-3">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="bg-background px-2 text-muted-foreground">یا</span>
              </div>
            </div>
            <Button
              type="button"
              variant="outline"
              className="w-full h-11"
              onClick={() => initiateGoogleLogin('/dashboard')}
            >
              <GoogleIcon className="w-5 h-5" />
              ثبت‌نام با گوگل
            </Button>
            <p className="text-[10px] text-muted-foreground text-center">
              با ورود با گوگل، هویت شما توسط گوگل تأیید می‌شود و نیازی به رمز عبور نیست.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}