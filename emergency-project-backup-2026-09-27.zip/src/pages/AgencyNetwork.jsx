import React, { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { useSarraafProfile } from '@/lib/useSarraaf';
import { offlineDB } from '@/lib/offlineQueue';
import { PageHeader, EmptyState, LoadingState, StatusBadge } from '@/components/sarraaf/Pieces';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { toast } from '@/components/ui/use-toast';
import { Share2, Plus, Copy } from 'lucide-react';

export default function AgencyNetwork() {
  const { user } = useAuth();
  const { data: profile, isLoading } = useSarraafProfile(user?.id);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [links, setLinks] = useState([]);
  const [form, setForm] = useState({ target_code: '', city: '', request_note: '' });

  React.useEffect(() => {
    if (user) loadLinks();
  }, [user]);

  const loadLinks = async () => {
    try {
      const all = await offlineDB.AgencyLink.list('-created_date', 500);
      setLinks(all.filter(l => l.requester_user_id === user.id || l.target_user_id === user.id));
    } catch {}
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!profile || !form.target_code) return;
    try {
      await offlineDB.AgencyLink.create({
        requester_profile_id: profile.id,
        requester_user_id: user.id,
        requester_code: profile.code,
        requester_name: profile.name,
        requester_exchange_name: profile.exchange_name,
        requester_phone: profile.phone,
        target_code: form.target_code,
        status: 'pending',
        city: form.city,
        request_note: form.request_note,
      });
      toast({ title: 'درخواست ارسال شد' });
      setDialogOpen(false);
      loadLinks();
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(profile?.code || '');
    toast({ title: 'کپی شد' });
  };

  if (isLoading) return <LoadingState />;

  return (
    <>
      <PageHeader title="شبکه نمایندگی" icon={Share2}
        actions={<Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="w-4 h-4" /> افزودن</Button>}
      />
      <div className="p-3 rounded-xl border bg-card mb-4 flex items-center justify-between">
        <div>
          <p className="text-xs text-muted-foreground">کد نمایندگی شما</p>
          <p className="text-lg font-bold">{profile?.code || '—'}</p>
        </div>
        <Button size="icon" variant="outline" onClick={copyCode}><Copy className="w-4 h-4" /></Button>
      </div>

      <h3 className="text-sm font-semibold mb-2">درخواست‌ها و اتصالات</h3>
      {links.length === 0 ? <EmptyState icon={Share2} title="اتصالی نیست" /> : (
        <div className="space-y-2">
          {links.map(l => (
            <div key={l.id} className="p-3 rounded-xl border bg-card">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">{l.requester_code === profile?.code ? l.target_name : l.requester_name}</span>
                <StatusBadge status={l.status} labels={{ pending: 'در انتظار', active: 'فعال', rejected: 'رد شده' }} />
              </div>
              {l.city && <p className="text-xs text-muted-foreground mt-1">شهر: {l.city}</p>}
            </div>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>افزودن نمایندگی</DialogTitle></DialogHeader>
          <form onSubmit={handleAdd} className="space-y-3">
            <div><Label>کد صرافی مقصد</Label><Input value={form.target_code} onChange={e => setForm({...form, target_code: e.target.value})} required /></div>
            <div><Label>شهر</Label><Input value={form.city} onChange={e => setForm({...form, city: e.target.value})} /></div>
            <div><Label>پیام</Label><Input value={form.request_note} onChange={e => setForm({...form, request_note: e.target.value})} /></div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>انصراف</Button>
              <Button type="submit">ارسال درخواست</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}