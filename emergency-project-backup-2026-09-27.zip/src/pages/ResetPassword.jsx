import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { callSupabase } from "@/lib/supabaseApi";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock, Loader2, AlertTriangle } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";

export default function ResetPassword() {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [hasSession, setHasSession] = useState(false);
  const [accessToken, setAccessToken] = useState("");
  const [checkingSession, setCheckingSession] = useState(true);

  // Check for Supabase Auth recovery code in URL hash or query
  useEffect(() => {
    const checkRecovery = async () => {
      try {
        const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));
        const queryParams = new URLSearchParams(window.location.search);
        const code = hashParams.get("code") || queryParams.get("code") || "";
        const type = hashParams.get("type") || queryParams.get("type") || "";

        if (code && type === "recovery") {
          const res = await callSupabase("auth_recover", { code });
          if (res?.success && res?.session?.access_token) {
            setAccessToken(res.session.access_token);
            setHasSession(true);
          }
        }
      } catch {
        // ignore — no valid recovery session
      }
      setCheckingSession(false);
    };
    checkRecovery();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (newPassword !== confirmPassword) {
      setError("رمز عبور و تکرار آن یکسان نیستند");
      return;
    }
    if (newPassword.length < 8) {
      setError("رمز عبور باید حداقل ۸ کاراکتر باشد");
      return;
    }
    setLoading(true);
    try {
      const res = await callSupabase("auth_updateUser", {
        access_token: accessToken,
        new_password: newPassword,
      });
      if (!res?.success) throw new Error(res?.error || "Failed to reset password");
      await callSupabase("auth_signOut", { access_token: accessToken });
      window.location.href = "/login";
    } catch (err) {
      setError(err.message || "Failed to reset password");
    } finally {
      setLoading(false);
    }
  };

  if (checkingSession) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!hasSession) {
    return (
      <AuthLayout
        icon={AlertTriangle}
        title="لینک نامعتبر"
        subtitle="لینک بازنشانی رمز عبور نامعتبر یا منقضی است"
        footer={
          <Link to="/forgot-password" className="text-primary font-medium hover:underline">
            درخواست لینک جدید
          </Link>
        }
      >
        <p className="text-sm text-foreground text-center">
          لینکی که استفاده کردید نامعتبر است یا منقضی شده است. لطفاً از طریق فراموشی رمز عبور، لینک جدیدی دریافت کنید.
        </p>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      icon={Lock}
      title="رمز عبور جدید"
      subtitle="رمز عبور جدید خود را وارد کنید"
    >
      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="password">رمز عبور جدید</Label>
          <div className="relative">
            <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="password"
              type="password"
              autoComplete="new-password"
              autoFocus
              placeholder="••••••••"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="pr-10 h-12"
              required
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirm">تکرار رمز عبور</Label>
          <div className="relative">
            <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="confirm"
              type="password"
              autoComplete="new-password"
              placeholder="••••••••"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="pr-10 h-12"
              required
            />
          </div>
        </div>
        <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 ml-2 animate-spin" />
              در حال بازنشانی...
            </>
          ) : (
            "بازنشانی رمز عبور"
          )}
        </Button>
      </form>
    </AuthLayout>
  );
}