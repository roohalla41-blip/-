import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Phone, ArrowRight, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { initiateGoogleLink, handleGoogleCallback } from '@/lib/googleAuth';
import GoogleIcon from '@/components/GoogleIcon';
import BrandMark from '@/components/BrandMark';

export default function ForgotPassword() {
  const [mobile, setMobile] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [linked, setLinked] = useState(false);
  const [error, setError] = useState('');

  // ── Google link callback handler ──
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('google_link') !== '1') return;
    setGoogleLoading(true);
    handleGoogleCallback().then((result) => {
      setGoogleLoading(false);
      if (!result) return;
      if (result.error) {
        setError(
          result.error === 'user_not_found'
            ? 'کاربری با این شماره موبایل یافت نشد'
            : result.error === 'email_exists'
            ? 'این حساب گوگل قبلاً به کاربر دیگری متصل شده است'
            : 'خطا در اتصال حساب گوگل'
        );
        window.history.replaceState({}, '', '/forgot-password');
        return;
      }
      if (result.linked) {
        setLinked(true);
        window.history.replaceState({}, '', '/forgot-password');
      }
    });
  }, []);

  const handleGoogleLink = (e) => {
    e.preventDefault();
    setError('');
    if (!mobile || mobile.length < 10) {
      setError('شماره موبایل معتبر وارد کنید');
      return;
    }
    initiateGoogleLink(mobile, '/forgot-password?google_link=1');
  };

  if (googleLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4">
        <div className="w-full max-w-md text-center space-y-4">
          <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto" />
          <p className="text-sm text-muted-foreground">در حال اتصال به گوگل...</p>
        </div>
      </div>
    );
  }

  if (linked) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-success/10 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8 text-success" />
            </div>
            <h1 className="text-lg font-bold">حساب گوگل متصل شد</h1>
            <p className="text-sm text-muted-foreground">
              اکنون می‌توانید با دکمه «ورود با گوگل» وارد حساب خود شوید.
              دیگر نیازی به رمز عبور ندارید.
            </p>
            <Link to="/login">
              <Button className="w-full h-11">
                <ArrowRight className="w-4 h-4" />
                بازگشت به ورود
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="flex justify-center mb-3">
            <BrandMark size="md" />
          </div>
          <h1 className="text-xl font-bold text-foreground">فراموشی رمز عبور</h1>
          <p className="text-xs text-muted-foreground mt-1">حساب صراف — سامانه تخصصی مدیریت صرافی</p>
          <p className="text-sm text-muted-foreground mt-1">
            حساب گوگل خود را متصل کنید تا بدون رمز عبور وارد شوید
          </p>
        </div>

        <div className="bg-card rounded-xl border shadow-sm p-6 space-y-4">
          <form onSubmit={handleGoogleLink} className="space-y-3">
            <div>
              <Label>شماره موبایل ثبت‌شده</Label>
              <div className="relative">
                <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="07XXXXXXXX"
                  className="pr-9"
                  inputMode="numeric"
                  dir="ltr"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 rounded-lg p-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            <Button type="submit" className="w-full h-11" disabled={loading}>
              <GoogleIcon className="w-5 h-5" />
              اتصال حساب گوگل
            </Button>
          </form>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-card px-2 text-muted-foreground">راهنما</span>
            </div>
          </div>

          <div className="space-y-2 text-xs text-muted-foreground">
            <p>۱. شماره موبایلی که با آن ثبت‌نام کرده‌اید را وارد کنید.</p>
            <p>۲. روی «اتصال حساب گوگل» بزنید و با حساب گوگل خود وارد شوید.</p>
            <p>۳. پس از اتصال، می‌توانید با گوگل وارد حساب خود شوید.</p>
          </div>
        </div>

        <div className="mt-6 text-center">
          <Link to="/login" className="text-xs text-muted-foreground hover:text-foreground">
            بازگشت به ورود
          </Link>
        </div>
      </div>
    </div>
  );
}