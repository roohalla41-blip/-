import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import {
  Settings as SettingsIcon, Coins, Crown,
  DatabaseBackup, ChevronLeft, FlaskConical, Store
} from 'lucide-react';
import ReferralCard from '@/components/sarraaf/ReferralCard';
import ContactInfo from '@/components/sarraaf/ContactInfo';
import SupportPanel from '@/components/sarraaf/SupportPanel';
import FeedbackButton from '@/components/sarraaf/FeedbackButton';
import MultiExchangeManager from '@/components/sarraaf/MultiExchangeManager';
import LanguageSettings from '@/components/sarraaf/LanguageSettings';
import TermsManager from '@/components/sarraaf/TermsManager';
import { useSarraafProfile, useToggleReferral } from '@/lib/useSarraaf';
import { useUpgrade } from '@/lib/UpgradeContext';
import { useAuth } from '@/lib/AuthContext';
import { getAllowedSettingsMenu, isManagementRole } from '@/lib/rbac';

const ALL_MENU_ITEMS = [
  { label: 'مدیریت ارزها', path: '/currencies', icon: Coins, color: 'text-amber-600' },
  { label: 'محصولات آنلاین', path: '/online-products', icon: Store, color: 'text-pink-600' },
  { label: 'بکاپ و بازیابی', path: '/backup', icon: DatabaseBackup, color: 'text-violet-600' },
];

export default function Settings() {
  const { user } = useAuth();
  const { user: authUser } = useAuth();
  const { data: profile } = useSarraafProfile(user?.id);
  const toggleMut = useToggleReferral();
  const { openUpgrade } = useUpgrade();

  const userRole = authUser?.role || 'user';
  const menuItems = ALL_MENU_ITEMS.filter(item =>
    getAllowedSettingsMenu(userRole).some(m => m.path === item.path)
  );

  const handleToggle = (enabled) => {
    if (!profile) return;
    toggleMut.mutate({ profileId: profile.id, enabled });
  };

  return (
    <>
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <SettingsIcon className="w-5 h-5 text-primary shrink-0" />
        <h1 className="text-lg font-bold">تنظیمات</h1>
      </div>

      {/* Upgrade card */}
      <Card className="mb-4 overflow-hidden border-0 shadow-sm">
        <CardContent className="p-4 bg-gradient-to-br from-primary to-indigo-600 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <Crown className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold">ارتقا به نسخه پولی</p>
              <p className="text-xs text-white/80">امکانات بیشتر و حذف برند سازنده</p>
            </div>
            <button
              onClick={() => openUpgrade()}
              className="px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-xs font-medium transition-colors shrink-0"
            >
              ارتقا
            </button>
          </div>
        </CardContent>
      </Card>

      {/* Referral card */}
      <div className="mb-4">
        <ReferralCard
          profile={profile}
          onToggle={handleToggle}
          loading={toggleMut.isPending}
        />
      </div>

      {/* Multi-exchange manager */}
      <div className="mb-4">
        <MultiExchangeManager />
      </div>

      {/* Language settings */}
      <div className="mb-4">
        <LanguageSettings />
      </div>

      {/* Contact links — read-only icons, managed from builder panel */}
      <div className="mb-4">
        <ContactInfo />
      </div>

      {/* Support panel */}
      <div className="mb-4">
        <SupportPanel />
      </div>

      {/* Vertical menu list */}
      <Card className="overflow-hidden">
        <CardContent className="p-0">
          {menuItems.map((item, idx) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3.5 hover:bg-muted/50 transition-colors ${
                  idx < menuItems.length - 1 ? 'border-b border-border' : ''
                }`}
              >
                <Icon className={`w-5 h-5 shrink-0 ${item.color}`} />
                <span className="text-sm font-medium flex-1">{item.label}</span>
                <ChevronLeft className="w-4 h-4 text-muted-foreground shrink-0" />
              </Link>
            );
          })}
        </CardContent>
      </Card>

      {/* Terms manager — admin/creator only */}
      {isManagementRole(userRole) && (
        <div className="mb-4">
          <TermsManager />
        </div>
      )}

      {/* About section */}
      <Card className="mt-4">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <FlaskConical className="w-4 h-4 text-muted-foreground" />
            <h3 className="text-xs font-semibold text-muted-foreground">نسخه برنامه</h3>
          </div>
          <p className="text-xs text-muted-foreground">همراه ما — سامانه مدیریت عملیات صرافی</p>
          <p className="text-xs text-muted-foreground mt-0.5">نسخه ۱.۰.۰</p>
          <div className="mt-3">
            <FeedbackButton />
          </div>
        </CardContent>
      </Card>
    </>
  );
}