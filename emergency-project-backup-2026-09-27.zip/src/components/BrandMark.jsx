import React from 'react';

/**
 * BrandMark — لوگوی برند «مادر 2026»
 * فقط نام متنی «مادر» و سال ۲۰۲۶ — بدون آیکون
 */
export default function BrandMark({
  size = 'md',
  showYear = true,
  className = '',
}) {
  const sizes = {
    sm: { title: 'text-sm', year: 'text-[10px]', bar: 'h-5' },
    md: { title: 'text-lg', year: 'text-xs', bar: 'h-6' },
    lg: { title: 'text-2xl', year: 'text-sm', bar: 'h-8' },
  };
  const s = sizes[size] || sizes.md;

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <span className={`${s.title} font-extrabold text-foreground leading-none tracking-tight`}>
        مادر
      </span>
      <span className={`w-px ${s.bar} bg-border/60`} />
      {showYear && (
        <span className={`${s.year} text-muted-foreground font-semibold tracking-wider`} dir="ltr">
          2026
        </span>
      )}
    </div>
  );
}