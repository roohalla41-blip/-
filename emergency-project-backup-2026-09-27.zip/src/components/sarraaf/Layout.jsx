import React, { useState, useEffect } from 'react';
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { useFeatures, useSarraafProfile } from '@/lib/useSarraaf';
import { visibleNavItems } from '@/lib/features';
import { shouldExpirePaidPlan } from '@/lib/permissions';
import { callSupabase } from '@/lib/supabaseApi';
import { useUpgrade } from '@/lib/UpgradeContext';
import SyncIndicator from '@/components/SyncIndicator';
import { Crown } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, Users, ArrowLeftRight, Repeat, Send, Download,
  Banknote, Landmark, Coins, FileText, TrendingUp, Settings, Shield,
  Network, Share2, BookOpen, BookCopy, ScrollText, ArrowRightLeft,
  ShoppingBag, Search, MoreVertical, X, MessageSquare, Wallet, Bell,
  Store, MessageSquareMore, DatabaseBackup, Copy, Headphones, CreditCard
} from 'lucide-react';
import { getAllowedNavItems, isManagementRole } from '@/lib/rbac';
import ExchangeMark from '@/components/ExchangeMark';
import TermsGate from '@/components/TermsGate';

const NAV_ITEMS = [
  { featureKey: 'dashboard', label: 'داشبورد', path: '/dashboard', icon: LayoutDashboard, order: 0 },
  { featureKey: 'customers', label: 'مشتریان', path: '/customers', icon: Users, order: 1 },
  { featureKey: 'dadogereft', label: 'داد و گرفت', path: '/dadogereft', icon: ArrowLeftRight, order: 2 },
  { featureKey: 'trade', label: 'خرید/فروش', path: '/trade', icon: Repeat, order: 3 },
  { featureKey: 'transfer_send', label: 'حواله ارسال', path: '/transfers/send', icon: Send, order: 4 },
  { featureKey: 'transfer_receive', label: 'حواله دریافت', path: '/transfers/receive', icon: Download, order: 5 },
  { featureKey: 'cash', label: 'صندوق', path: '/cash', icon: Banknote, order: 6 },
  { featureKey: 'bank', label: 'بانک', path: '/bank', icon: Landmark, order: 7 },
  { featureKey: 'currencies', label: 'ارز و نرخ', path: '/currencies', icon: Coins, order: 8 },
  { featureKey: 'reports', label: 'گزارش‌ها', path: '/reports', icon: FileText, order: 9 },
  { featureKey: 'profit_loss', label: 'سود و زیان', path: '/profit-loss', icon: TrendingUp, order: 10 },
  { featureKey: 'debtors', label: 'بدهکاران', path: '/debtors', icon: Wallet, order: 12 },
  { featureKey: 'agents', label: 'نمایندگی‌ها', path: '/agents', icon: Network, order: 13 },
  { featureKey: 'agency_network', label: 'شبکه نمایندگی', path: '/agency-network', icon: Share2, order: 14 },
  { featureKey: 'transfer_book', label: 'دفتر حواله', path: '/transfer-book', icon: BookOpen, order: 15 },
  { featureKey: 'journal', label: 'دفتر روزنامه', path: '/journal', icon: BookCopy, order: 16 },
  { featureKey: 'general_ledger', label: 'دفتر کل', path: '/general-ledger', icon: ScrollText, order: 17 },
  { featureKey: 'convert', label: 'تبدیل ارز', path: '/convert', icon: ArrowRightLeft, order: 18 },
  { featureKey: 'online_products', label: 'محصولات آنلاین', path: '/online-products', icon: ShoppingBag, order: 19 },
  { featureKey: 'payment_gateway', label: 'درگاه پرداخت', path: '/payment-gateway', icon: CreditCard, order: 19.5 },
  { featureKey: 'settings', label: 'تنظیمات', path: '/settings', icon: Settings, order: 11 },
  { featureKey: 'sarraaf_market', label: 'بازار نرخ', path: '/sarraaf-market', icon: Store, order: 20 },
  { featureKey: 'sarraaf_chat', label: 'چت صراف‌ها', path: '/sarraaf-chat', icon: MessageSquareMore, order: 21 },
  { featureKey: 'chat_groups', label: 'چت و گروه‌ها', path: '/chat', icon: MessageSquare, order: 22 },
  { featureKey: 'backup', label: 'بکاپ و بازیابی', path: '/backup', icon: DatabaseBackup, order: 23 },
  { featureKey: 'support', label: 'پشتیبانی آنلاین', path: '/support', icon: Headphones, order: 24 },
];

const BOTTOM_NAV = [
  { featureKey: 'dashboard', label: 'خانه', path: '/dashboard', icon: LayoutDashboard },
  { featureKey: 'customers', label: 'مشتریان', path: '/customers', icon: Users },
  { featureKey: 'trade', label: 'خرید/فروش', path: '/trade', icon: Repeat },
  { featureKey: 'transfer_book', label: 'حواله', path: '/transfer-book', icon: BookOpen },
  { featureKey: 'settings', label: 'تنظیمات', path: '/settings', icon: Settings },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const { data: features } = useFeatures();
  const { data: profile } = useSarraafProfile(user?.id);
  const [moreOpen, setMoreOpen] = useState(false);
  const { openUpgrade } = useUpgrade();

  const userRole = user?.role || 'user';
  const featureFiltered = visibleNavItems(features || [], NAV_ITEMS, profile || user);
  const items = getAllowedNavItems(userRole, featureFiltered);
  const bottomItems = items.filter(i => BOTTOM_NAV.some(b => b.featureKey === i.featureKey));
  const bottomPaths = new Set(BOTTOM_NAV.map(b => b.featureKey));
  const moreItems = items.filter(i => !bottomPaths.has(i.featureKey));

  // Auto-expire paid plan if end date has passed
  useEffect(() => {
    if (!profile) return;
    if (shouldExpirePaidPlan(profile)) {
      callSupabase('crud', {
        table: 'exchanges',
        operation: 'update',
        id: String(profile.id),
        data: { plan: 'free', payment_status: 'expired' },
      }).catch((err) => console.error('Failed to expire paid plan:', err.message));
    }
  }, [profile?.id, profile?.plan, profile?.paid_end_date]);

  const handleLogout = () => {
    logout();
  };

  return (
    <TermsGate role={userRole}>
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col border-l bg-sidebar border-sidebar-border shrink-0">
        <div className="p-4 border-b border-sidebar-border">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <div className="shrink-0">
                <ExchangeMark size="sm" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold truncate">{profile?.exchange_name || profile?.name || 'حساب صراف'}</p>
                {profile?.code && (
                  <div className="flex items-center gap-1">
                    <p className="text-xs text-muted-foreground tracking-wider truncate" dir="ltr">{profile.code}</p>
                    <button
                      onClick={() => {
                        navigator.clipboard?.writeText(profile.code);
                      }}
                      className="p-0.5 rounded text-muted-foreground hover:text-primary transition-colors shrink-0"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <SyncIndicator compact />
              <Link to="/online-products" className="p-1.5 rounded-lg text-muted-foreground hover:bg-sidebar-accent transition-colors">
                <ShoppingBag className="w-4 h-4" />
              </Link>
              <Link to="/notifications" className="p-1.5 rounded-lg text-muted-foreground hover:bg-sidebar-accent transition-colors">
                <Bell className="w-4 h-4" />
              </Link>
              <button onClick={() => openUpgrade()} className="p-1.5 rounded-lg text-primary hover:bg-primary/10 transition-colors">
                <Crown className="w-4 h-4" />
              </button>
              {isManagementRole(userRole) && (
                <>
                  <Link to={userRole === 'creator' ? '/builder' : '/dashboard'} className="p-1.5 rounded-lg text-primary hover:bg-primary/10 transition-colors">
                    <Shield className="w-4 h-4" />
                  </Link>
                  {userRole === 'creator' && (
                    <Link to="/main-settings" className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors">
                      <Settings className="w-4 h-4" />
                    </Link>
                  )}
                </>
              )}
              <button onClick={handleLogout} className="p-1.5 rounded-lg text-destructive hover:bg-destructive/10 transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="px-3 py-2 border-b border-sidebar-border">
          <div className="relative">
            <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
            type="text"
            placeholder="جستجو..."
            className="w-full pr-8 pl-3 py-1.5 text-sm rounded-lg bg-muted border border-transparent focus:border-primary outline-none"
            onFocus={() => navigate('/customers')}
            />
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto scrollbar-thin py-2">
          {items.map(item => {
            const Icon = item.icon;
            const active = location.pathname === item.path || location.pathname.startsWith(item.path + '/');
            return (
              <Link
                key={item.featureKey}
                to={item.path}
                className={cn(
                  'flex items-center gap-2 px-4 py-2.5 text-sm transition-colors',
                  active
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground font-medium border-r-2 border-sidebar-primary'
                    : 'text-sidebar-foreground/80 hover:bg-sidebar-accent/50'
                )}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-3 border-t border-sidebar-border">
          <SyncIndicator />
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header — clean, minimal: identity + hamburger */}
        <header className="lg:hidden sticky top-0 z-30 bg-card border-b">
          <div className="flex items-center justify-between gap-2 px-4 py-3">
            {/* Exchange identity */}
            <div className="flex items-center gap-2 min-w-0">
              <div className="shrink-0">
                <ExchangeMark size="sm" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold truncate leading-tight">{profile?.exchange_name || profile?.name || 'حساب صراف'}</p>
                {profile?.code && (
                  <div className="flex items-center gap-1">
                    <p className="text-[10px] text-muted-foreground tracking-wider truncate" dir="ltr">{profile.code}</p>
                    <button
                      onClick={() => navigator.clipboard?.writeText(profile.code)}
                      className="p-0.5 rounded text-muted-foreground hover:text-primary transition-colors shrink-0"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Sync indicator + Notifications + Hamburger menu */}
            <div className="flex items-center gap-1 shrink-0">
              <SyncIndicator compact />
              <Link to="/notifications" className="w-9 h-9 rounded-lg hover:bg-muted flex items-center justify-center transition-colors">
                <Bell className="w-5 h-5" />
              </Link>
              <button
                onClick={() => setMoreOpen(true)}
                className="w-9 h-9 rounded-lg hover:bg-muted flex items-center justify-center transition-colors"
              >
                <MoreVertical className="w-5 h-5" />
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto pb-20 lg:pb-12">
          <div className="max-w-5xl mx-auto p-3 lg:p-6">
            <Outlet />
          </div>
        </main>
      </div>

      {/* Mobile Bottom Nav — 5 tabs */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-card border-t flex items-center justify-around px-1 pt-1 pb-0 safe-bottom">
        {bottomItems.map(item => {
          const Icon = item.icon;
          const active = location.pathname === item.path || location.pathname.startsWith(item.path + '/');
          return (
            <Link
              key={item.featureKey}
              to={item.path}
              className={cn(
                'flex flex-col items-center gap-0.5 px-2 pt-1 pb-1 rounded-lg flex-1 transition-colors',
                active ? 'text-primary bg-primary/10' : 'text-muted-foreground'
              )}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Hamburger Menu Drawer */}
      {moreOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/50" onClick={() => setMoreOpen(false)}>
          <div className="absolute top-0 left-0 bottom-0 w-72 bg-card shadow-xl overflow-y-auto scrollbar-thin" onClick={e => e.stopPropagation()}>
            {/* Drawer header with identity */}
            <div className="p-4 border-b bg-gradient-to-l from-primary to-primary/80">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="shrink-0">
                    <ExchangeMark size="sm" dark />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-white truncate">{profile?.exchange_name || profile?.name || 'حساب صراف'}</p>
                    {profile?.code && (
                      <p className="text-[10px] text-white/70 tracking-wider truncate" dir="ltr">{profile.code}</p>
                    )}
                  </div>
                </div>
                <button onClick={() => setMoreOpen(false)} className="p-1.5 rounded-lg text-white/80 hover:bg-white/10">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* All nav items */}
            <nav className="p-2">
              {moreItems.map(item => {
                const Icon = item.icon;
                const active = location.pathname === item.path || location.pathname.startsWith(item.path + '/');
                return (
                  <Link
                    key={item.featureKey}
                    to={item.path}
                    onClick={() => setMoreOpen(false)}
                    className={cn(
                      'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors',
                      active ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-muted'
                    )}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </Link>
                );
              })}
            </nav>

            {/* Management actions */}
            <div className="p-2 border-t mt-2 space-y-1">
              <div className="flex items-center justify-between px-3 py-2">
                <span className="text-xs text-muted-foreground">همگام‌سازی</span>
                <SyncIndicator compact />
              </div>
              <Link to="/online-products" onClick={() => setMoreOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20">
                <ShoppingBag className="w-4 h-4 shrink-0" />
                <span>محصولات آنلاین</span>
              </Link>
              <Link to="/notifications" onClick={() => setMoreOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/20">
                <Bell className="w-4 h-4 shrink-0" />
                <span>اعلان‌ها</span>
              </Link>
              <button onClick={() => { setMoreOpen(false); openUpgrade(); }} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-yellow-600 hover:bg-yellow-50 dark:hover:bg-yellow-900/20">
                <Crown className="w-4 h-4 shrink-0" />
                <span>ارتقا به نسخه پولی</span>
              </button>
              {userRole === 'creator' && (
                <>
                  <Link to="/builder" onClick={() => setMoreOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-violet-600 hover:bg-violet-50 dark:hover:bg-violet-900/20">
                    <Shield className="w-4 h-4 shrink-0" />
                    <span>پنل سازنده</span>
                  </Link>
                  <Link to="/main-settings" onClick={() => setMoreOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20">
                    <Settings className="w-4 h-4 shrink-0" />
                    <span>تنظیمات اصلی</span>
                  </Link>
                </>
              )}
              <button onClick={() => { setMoreOpen(false); handleLogout(); }} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-destructive hover:bg-destructive/10">
                <X className="w-4 h-4 shrink-0" />
                <span>خروج</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
    </TermsGate>
  );
}