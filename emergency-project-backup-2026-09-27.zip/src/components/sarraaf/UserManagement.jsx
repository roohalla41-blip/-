import React, { useState, useMemo } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useAllSarraafProfiles, useAllCustomers, useAllTransactions, useAllMessages, useActivatePaidPlan, useExpirePaidPlan, useUpdateSarraafProfile } from '@/lib/useAdmin';
import { getPlanStatus, getPlanDisplay } from '@/lib/permissions';
import { useAuth } from '@/lib/AuthContext';
import { callSupabase } from '@/lib/supabaseApi';
import { RefreshCw } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { Search, Crown, Clock, UserX, UserCheck, Users, Activity, MessageSquare, Store } from 'lucide-react';
import { generateUniqueInviteCode } from '@/lib/referralSystem';
import InviteCodeManager from './InviteCodeManager';

// ── Sync users from Supabase server to Base44 entities ──
// Creates SarraafProfile for sarraaf users and Customer for customer users
// that exist on the server but don't have local records yet.
export async function syncUsersFromServer() {
  const auth_token = typeof localStorage !== 'undefined' ? localStorage.getItem('auth_token') : '';
  const [usersRes, exRes] = await Promise.all([
    callSupabase('listUsers', { auth_token }),
    callSupabase('listExchanges', { auth_token }),
  ]);
  const users = usersRes?.users || [];
  const exchanges = exRes?.exchanges || [];

  const { offlineDB } = await import('@/lib/offlineQueue');
  const existingProfiles = await offlineDB.SarraafProfile.list('-created_date', 500);
  const existingCustomers = await offlineDB.Customer.list('-created_date', 500);
  const profileUserIds = new Set(existingProfiles.map(p => String(p.user_id || '')));
  const profileEmails = new Set(existingProfiles.map(p => (p.email || '').toLowerCase()).filter(Boolean));
  const customerPhones = new Set(existingCustomers.map(c => (c.phone || '').trim()));

  let created = 0;

  // 1) Sync from Supabase users table
  for (const u of users) {
    const uid = String(u.id || '');
    const role = u.role || '';
    const email = (u.email || '').toLowerCase();
    // Sarraaf users — create SarraafProfile if missing (also check by email for Gmail users)
    if ((role === 'exchange' || role === 'sarraaf') && !profileUserIds.has(uid) && !(email && profileEmails.has(email))) {
      const ex = exchanges.find(e => String(e.user_id || '') === uid) || exchanges.find(e => e.exchange_name && u.full_name && u.full_name.includes(e.exchange_name));
      try {
        const inviteCode = await generateUniqueInviteCode('SR');
        await offlineDB.SarraafProfile.create({
          code: ex?.exchange_code || `EX-${uid.slice(-5)}`,
          user_id: uid,
          email: u.email || '',
          exchange_name: ex?.exchange_name || '',
          name: u.full_name || u.username || 'صراف',
          phone: u.mobile || '',
          plan: 'free',
          quota_limit: 100,
          quota_used: 0,
          payment_status: 'none',
          status: u.status === 'suspended' ? 'suspended' : 'active',
          last_login: u.last_login || u.created_date || new Date().toISOString(),
          referral_enabled: true,
          referral_code: inviteCode,
        });
        created++;
      } catch { /* ignore individual failures */ }
    }
    // Customer users — create Customer if missing
    if (role === 'customer' && u.mobile && !customerPhones.has(u.mobile.trim())) {
      try {
        await offlineDB.Customer.create({
          name: u.full_name || 'مشتری',
          phone: u.mobile,
          code: `CUS-${uid.slice(-6)}`,
          status: u.status === 'active' ? 'active' : 'inactive',
          customer_type: 'permanent',
          notes: `همگام‌سازی از سرور — ${new Date().toLocaleDateString('fa-IR')}`,
        });
        created++;
      } catch { /* ignore individual failures */ }
    }
  }

  // Note: Base44 User entity sync removed — all users now come from Supabase users table via listUsers action.

  return { created };
}

function toFa(n) {
  return Number(n || 0).toLocaleString('fa-IR');
}

export default function UserManagement() {
  const { user } = useAuth();
  const { data: profiles, isLoading: loadingSarraaf } = useAllSarraafProfiles();
  const { data: customers, isLoading: loadingCustomer } = useAllCustomers();
  const { data: transactions } = useAllTransactions();
  const { data: messages } = useAllMessages();
  const activateMut = useActivatePaidPlan();
  const expireMut = useExpirePaidPlan();
  const updateMut = useUpdateSarraafProfile();

  const [tab, setTab] = useState('sarraaf');
  const [search, setSearch] = useState('');
  const [filterPlan, setFilterPlan] = useState('all');
  const [editProfile, setEditProfile] = useState(null);
  const [planForm, setPlanForm] = useState({ plan: 'pro', startDate: '', endDate: '', durationMonths: 1 });
  const [syncing, setSyncing] = useState(false);
  const qc = useQueryClient();

  // Build usage stats map: user_id → { txCount, msgCount }
  const usageMap = useMemo(() => {
    const map = {};
    for (const tx of (transactions || [])) {
      const uid = tx.created_by_id || tx.customer_id || '';
      if (uid) {
        if (!map[uid]) map[uid] = { txCount: 0, msgCount: 0 };
        map[uid].txCount++;
      }
    }
    for (const msg of (messages || [])) {
      const uid = msg.sender_id || '';
      if (uid) {
        if (!map[uid]) map[uid] = { txCount: 0, msgCount: 0 };
        map[uid].msgCount++;
      }
    }
    return map;
  }, [transactions, messages]);

  const filteredSarraaf = useMemo(() => {
    let list = profiles || [];
    if (search) {
      const s = search.toLowerCase();
      list = list.filter(p =>
        (p.name || '').toLowerCase().includes(s) ||
        (p.code || '').toLowerCase().includes(s) ||
        (p.phone || '').includes(s)
      );
    }
    if (filterPlan !== 'all') {
      list = list.filter(p => getPlanStatus(p) === filterPlan);
    }
    return list;
  }, [profiles, search, filterPlan]);

  const filteredCustomers = useMemo(() => {
    let list = customers || [];
    if (search) {
      const s = search.toLowerCase();
      list = list.filter(c =>
        (c.name || '').toLowerCase().includes(s) ||
        (c.phone || '').includes(s) ||
        (c.code || '').toLowerCase().includes(s)
      );
    }
    return list;
  }, [customers, search]);

  const openActivate = (profile) => {
    setEditProfile(profile);
    const today = new Date().toISOString().slice(0, 10);
    const end = new Date();
    end.setFullYear(end.getFullYear() + 1);
    end.setDate(end.getDate() - 1);
    setPlanForm({ plan: 'pro', startDate: today, endDate: end.toISOString().slice(0, 10), durationMonths: 12 });
  };

  const handleDurationChange = (months) => {
    const start = new Date(planForm.startDate || new Date().toISOString().slice(0, 10));
    const end = new Date(start);
    end.setMonth(end.getMonth() + months);
    end.setDate(end.getDate() - 1);
    setPlanForm({ ...planForm, durationMonths: months, endDate: end.toISOString().slice(0, 10) });
  };

  const handleActivate = async () => {
    if (!editProfile) return;
    try {
      await activateMut.mutateAsync({
        profile: editProfile,
        plan: planForm.plan,
        startDate: planForm.startDate,
        endDate: planForm.endDate,
        confirmedByName: user?.full_name || user?.email || 'مدیر سیستم',
      });
      toast({ title: 'فعال شد', description: 'نسخه پولی برای کاربر فعال شد' });
      setEditProfile(null);
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleExpire = async (profile) => {
    if (!confirm(`پایان اعتبار نسخه پولی ${profile.name}؟`)) return;
    try {
      await expireMut.mutateAsync({
        profile,
        sentByName: user?.full_name || user?.email || 'مدیر سیستم',
      });
      toast({ title: 'منقضی شد', description: 'حساب کاربر به نسخه رایگان بازگشت' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleToggleStatus = async (profile) => {
    try {
      await updateMut.mutateAsync({
        id: profile.id,
        data: { status: profile.status === 'active' ? 'suspended' : 'active' },
      });
      toast({ title: 'تغییر وضعیت', description: profile.status === 'active' ? 'حساب معلق شد' : 'حساب فعال شد' });
    } catch (err) {
      toast({ title: 'خطا', description: err.message, variant: 'destructive' });
    }
  };

  const handleSyncFromServer = async () => {
    setSyncing(true);
    try {
      const result = await syncUsersFromServer();
      toast({ title: 'همگام‌سازی شد', description: `${toFa(result.created)} کاربر جدید از سرور اضافه شد` });
      qc.invalidateQueries({ queryKey: ['allSarraafProfiles'] });
      qc.invalidateQueries({ queryKey: ['allCustomersAdmin'] });
    } catch (err) {
      toast({ title: 'خطا', description: err.message || 'همگام‌سازی ناموفق بود', variant: 'destructive' });
    }
    setSyncing(false);
  };

  const planBadge = (p) => {
    const d = getPlanDisplay(p);
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${d.bg} ${d.color}`}>
        {d.icon} {d.label}
      </span>
    );
  };

  const isLoading = loadingSarraaf || loadingCustomer;

  return (
    <div>
      <InviteCodeManager />
      <Card>
        <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <Crown className="w-4 h-4" />
            مدیریت کاربران و اشتراک
          </h3>
          <Button size="sm" variant="outline" onClick={handleSyncFromServer} disabled={syncing}>
            <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'در حال همگام‌سازی...' : 'همگام‌سازی از سرور'}
          </Button>
        </div>

        {/* Tab switcher: Sarraaf / Customer */}
        <div className="flex gap-1 p-1 rounded-xl bg-muted mb-3">
          <button
            onClick={() => setTab('sarraaf')}
            className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${tab === 'sarraaf' ? 'bg-card shadow text-foreground' : 'text-muted-foreground'}`}
          >
            <Store className="w-3.5 h-3.5" />
            صراف‌ها ({toFa((profiles || []).length)})
          </button>
          <button
            onClick={() => setTab('customer')}
            className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${tab === 'customer' ? 'bg-card shadow text-foreground' : 'text-muted-foreground'}`}
          >
            <Users className="w-3.5 h-3.5" />
            مشتریان ({toFa((customers || []).length)})
          </button>
        </div>

        <div className="flex gap-2 mb-3">
          <div className="relative flex-1">
            <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="جستجو نام / کد / تلفن"
              className="pr-8"
            />
          </div>
          {tab === 'sarraaf' && (
            <Select value={filterPlan} onValueChange={setFilterPlan}>
              <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه</SelectItem>
                <SelectItem value="free">رایگان</SelectItem>
                <SelectItem value="paid_active">پولی فعال</SelectItem>
                <SelectItem value="paid_expired">منقضی‌شده</SelectItem>
              </SelectContent>
            </Select>
          )}
        </div>

        {isLoading ? (
          <p className="text-xs text-muted-foreground">در حال بارگذاری...</p>
        ) : tab === 'sarraaf' ? (
          filteredSarraaf.length === 0 ? (
            <p className="text-xs text-muted-foreground">صرافی یافت نشد</p>
          ) : (
            <div className="space-y-2">
              {filteredSarraaf.map(p => {
                const usage = usageMap[p.user_id || p.id] || { txCount: 0, msgCount: 0 };
                return (
                  <div key={p.id} className="p-3 rounded-lg border space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-medium truncate">{p.name}</span>
                          {planBadge(p)}
                          {p.status === 'suspended' && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-50 text-red-600">معلق</span>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-[10px] text-muted-foreground">
                          <span>کد: {p.code}</span>
                          {p.phone && <span>تلفن: {p.phone}</span>}
                          {p.exchange_name && <span>صرافی: {p.exchange_name}</span>}
                        </div>
                        <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-0.5 text-[10px] text-muted-foreground">
                          <span>سهمیه: {toFa(p.quota_used)} / {toFa(p.quota_limit)}</span>
                          {p.paid_start_date && <span>شروع: {p.paid_start_date}</span>}
                          {p.paid_end_date && <span>پایان: {p.paid_end_date}</span>}
                          {p.last_login && <span>آخرین ورود: {new Date(p.last_login).toLocaleDateString('fa-IR')}</span>}
                        </div>
                        {/* Usage stats */}
                        <div className="flex gap-2 mt-1.5">
                          <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">
                            <Activity className="w-3 h-3" />
                            {toFa(usage.txCount)} تراکنش
                          </span>
                          <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-blue-50 text-blue-600">
                            <MessageSquare className="w-3 h-3" />
                            {toFa(usage.msgCount)} پیام
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-1 flex-wrap">
                      <Button size="sm" variant="outline" onClick={() => openActivate(p)}>
                        <Crown className="w-3 h-3" />
                        ارتقا به پولی
                      </Button>
                      {getPlanStatus(p) !== 'free' && (
                        <Button size="sm" variant="ghost" onClick={() => handleExpire(p)}>
                          <Clock className="w-3 h-3" />
                          پایان اعتبار
                        </Button>
                      )}
                      <Button size="sm" variant="ghost" onClick={() => handleToggleStatus(p)}>
                        {p.status === 'active' ? <UserX className="w-3 h-3" /> : <UserCheck className="w-3 h-3" />}
                        {p.status === 'active' ? 'تعلیق' : 'فعال‌سازی'}
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )
        ) : (
          /* Customer list */
          filteredCustomers.length === 0 ? (
            <p className="text-xs text-muted-foreground">مشتری یافت نشد</p>
          ) : (
            <div className="space-y-2">
              {filteredCustomers.map(c => {
                const usage = usageMap[c.id] || { txCount: 0, msgCount: 0 };
                return (
                  <div key={c.id} className="p-3 rounded-lg border space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-medium truncate">{c.name}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-50 text-blue-600">مشتری</span>
                          {c.status === 'inactive' && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-50 text-red-600">غیرفعال</span>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-[10px] text-muted-foreground">
                          <span>کد: {c.code || '—'}</span>
                          {c.phone && <span>تلفن: {c.phone}</span>}
                          {c.customer_type && <span>نوع: {c.customer_type === 'permanent' ? 'ثابت' : c.customer_type === 'temporary' ? 'موقت' : 'متفرقه'}</span>}
                        </div>
                        {/* Usage stats */}
                        <div className="flex gap-2 mt-1.5">
                          <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">
                            <Activity className="w-3 h-3" />
                            {toFa(usage.txCount)} تراکنش
                          </span>
                          <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-blue-50 text-blue-600">
                            <MessageSquare className="w-3 h-3" />
                            {toFa(usage.msgCount)} پیام
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )
        )}
      </CardContent>

      <Dialog open={!!editProfile} onOpenChange={() => setEditProfile(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>فعال‌سازی نسخه پولی — {editProfile?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>نوع پلن</Label>
              <Select value={planForm.plan} onValueChange={v => setPlanForm({ ...planForm, plan: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="basic">پایه</SelectItem>
                  <SelectItem value="pro">حرفه‌ای</SelectItem>
                  <SelectItem value="special">ویژه</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label>تاریخ شروع</Label>
                <Input type="date" value={planForm.startDate} onChange={e => setPlanForm({ ...planForm, startDate: e.target.value })} />
              </div>
              <div>
                <Label>تاریخ پایان</Label>
                <Input type="date" value={planForm.endDate} onChange={e => setPlanForm({ ...planForm, endDate: e.target.value })} />
              </div>
            </div>
            <div>
              <Label>مدت اشتراک</Label>
              <Select value={String(planForm.durationMonths)} onValueChange={v => handleDurationChange(parseInt(v))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="12">یک ساله</SelectItem>
                  <SelectItem value="6">شش ماهه</SelectItem>
                  <SelectItem value="3">سه ماهه</SelectItem>
                  <SelectItem value="1">یک ماهه</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditProfile(null)}>انصراف</Button>
            <Button onClick={handleActivate} disabled={activateMut.isPending}>
              {activateMut.isPending ? 'در حال فعال‌سازی...' : 'فعال‌سازی نسخه پولی'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
    </div>
  );
}