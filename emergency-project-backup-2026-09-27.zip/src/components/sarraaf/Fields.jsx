import React, { useState, useMemo, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toEnglishDigits } from '@/lib/sarraaf';
import { DEFAULT_CURRENCIES } from '@/lib/defaultCurrencies';

export function Field({ label, required, children, className }) {
  return (
    <div className={className}>
      {label && (
        <Label className="mb-1 block">
          {label} {required && <span className="text-destructive">*</span>}
        </Label>
      )}
      {children}
    </div>
  );
}

export function AmountInput({ value, onChange, placeholder = 'مبلغ', disabled }) {
  const [display, setDisplay] = useState(value ? new Intl.NumberFormat('en-US').format(value) : '');

  useEffect(() => {
    const formatted = value ? new Intl.NumberFormat('en-US').format(value) : '';
    setDisplay(formatted);
  }, [value]);

  const handle = (e) => {
    const raw = toEnglishDigits(e.target.value).replace(/[^\d.]/g, '');
    setDisplay(raw ? new Intl.NumberFormat('en-US').format(parseFloat(raw)) : '');
    onChange(raw ? parseFloat(raw) : 0);
  };
  return (
    <Input
      type="text"
      inputMode="numeric"
      value={display}
      onChange={handle}
      placeholder={placeholder}
      disabled={disabled}
      className="text-left font-mono"
    />
  );
}

// Sort currencies: AFN first, USD second, then others by sort_order
function sortCurrencies(list) {
  return [...list].sort((a, b) => {
    if (a.code === 'AFN') return -1;
    if (b.code === 'AFN') return 1;
    if (a.code === 'USD') return -1;
    if (b.code === 'USD') return 1;
    return (a.sort_order || 0) - (b.sort_order || 0);
  });
}

export function CurrencySelect({ value, onChange, currencies, disabled }) {
  const list = sortCurrencies((currencies && currencies.length > 0 ? currencies : DEFAULT_CURRENCIES).filter(c => c.is_active !== false));
  const fiatList = list.filter(c => c.type !== 'crypto');
  const cryptoList = list.filter(c => c.type === 'crypto');
  return (
    <Select value={value} onValueChange={onChange} disabled={disabled}>
      <SelectTrigger>
        <SelectValue placeholder="انتخاب ارز" />
      </SelectTrigger>
      <SelectContent>
        {fiatList.length > 0 && (
          <>
            <div className="px-2 py-1 text-[10px] font-medium text-muted-foreground pointer-events-none">ارزهای رایج</div>
            {fiatList.map(c => (
              <SelectItem key={c.code} value={c.code}>
                {c.symbol ? `${c.symbol}` : c.code} — {c.name}
              </SelectItem>
            ))}
          </>
        )}
        {cryptoList.length > 0 && (
          <>
            <div className="px-2 py-1 text-[10px] font-medium text-muted-foreground pointer-events-none">دارایی‌های دیجیتال</div>
            {cryptoList.map(c => (
              <SelectItem key={c.code} value={c.code}>
                {c.symbol ? `${c.symbol}` : c.code} — {c.name}
              </SelectItem>
            ))}
          </>
        )}
      </SelectContent>
    </Select>
  );
}

export function CounterAccountSelect({ value, onChange, bankAccounts, agents, type, onTypeChange }) {
  const accounts = useMemo(() => {
    if (type === 'bank') return bankAccounts || [];
    if (type === 'agent') return agents || [];
    return [];
  }, [type, bankAccounts, agents]);

  return (
    <div className="space-y-2">
      <Select value={type || 'none'} onValueChange={onTypeChange}>
        <SelectTrigger><SelectValue placeholder="حساب مقابل" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="none">هیچ</SelectItem>
          <SelectItem value="cash">صندوق</SelectItem>
          <SelectItem value="bank">بانک</SelectItem>
          <SelectItem value="agent">نماینده</SelectItem>
        </SelectContent>
      </Select>
      {type !== 'none' && type !== 'cash' && accounts.length > 0 && (
        <Select value={value || ''} onValueChange={onChange}>
          <SelectTrigger><SelectValue placeholder="انتخاب حساب" /></SelectTrigger>
          <SelectContent>
            {accounts.map(a => (
              <SelectItem key={a.id} value={a.id}>
                {a.bank_name || a.name} {a.holder ? `- ${a.holder}` : ''}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
    </div>
  );
}

export function AgentSelect({ value, onChange, agents }) {
  return (
    <Select value={value || ''} onValueChange={onChange}>
      <SelectTrigger><SelectValue placeholder="نماینده" /></SelectTrigger>
      <SelectContent>
        {(agents || []).map(a => (
          <SelectItem key={a.id} value={a.id}>{a.name} {a.code ? `(${a.code})` : ''}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

export function parseCounter(type, id) {
  return { counter_type: type || 'none', counter_id: id || null };
}