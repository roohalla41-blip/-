import React from 'react';
import { Mail, Phone, Globe, MessageCircle, Send, Instagram, Facebook } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { getContactSettings, getContactUrl } from '@/lib/contactSettings';
import { useToast } from '@/components/ui/use-toast';

const ICON_MAP = { Phone, Mail, Globe, MessageCircle, Send, Instagram, Facebook };

export default function ContactInfo() {
  const { toast } = useToast();
  const { data: contacts, isLoading } = useQuery({
    queryKey: ['contactSettings'],
    queryFn: getContactSettings,
  });

  // Show all active contacts — links are managed from the builder panel
  const visible = (contacts || []).filter(c => c.is_active);

  function handleClick(type, value) {
    if (!value) {
      toast({ title: 'لینک تنظیم نشده', description: 'این لینک هنوز توسط مدیر سیستم تنظیم نشده است' });
      return;
    }
    const url = getContactUrl(type, value);
    if (url === '#') return;
    window.open(url, '_blank');
  }

  if (isLoading || visible.length === 0) return null;

  return (
    <Card>
      <CardContent className="p-3">
        <p className="text-xs font-semibold text-muted-foreground mb-2">لینک‌های ارتباطی</p>
        <div className="grid grid-cols-4 gap-2">
          {visible.map((c) => {
            const Icon = ICON_MAP[c.icon] || Phone;
            return (
              <button
                key={c.type}
                onClick={() => handleClick(c.type, c.value)}
                className="flex flex-col items-center gap-1 p-2 rounded-xl border border-border hover:bg-muted/50 transition-colors"
              >
                <Icon className="w-5 h-5 text-primary" />
                <span className="text-[10px] text-muted-foreground">{c.label}</span>
              </button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}